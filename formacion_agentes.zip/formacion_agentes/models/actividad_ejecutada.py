from odoo import models, fields


class ActividadEjecutada(models.Model):
    _name = "actividad.ejecutada"
    _description = "Actividad Ejecutada"

    name = fields.Char(
        string="Registro",
        default="Nueva Actividad"
    )