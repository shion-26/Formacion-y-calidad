from odoo import fields, models


class ActividadEjecutada(models.Model):
    _name = "actividad.ejecutada"
    _description = "Actividades Ejecutadas"


    # ==========================================================
    # 1. INFORMACIÓN GENERAL
    # ==========================================================

    id_actividad = fields.Char(
        string="ID Actividad",
        required=True,
    )

    fecha_programada = fields.Date(
        string="Fecha programada",
        required=True,
    )

    fecha_ejecucion = fields.Date(
        string="Fecha de ejecución",
        required=True,
    )

    hora_inicio_real = fields.Float(
        string="Hora inicio real",
        required=True,
    )

    hora_fin_real = fields.Float(
        string="Hora fin real",
        required=True,
    )

    duracion_real = fields.Float(
        string="Duración real",
    )

    modalidad = fields.Selection(
        [
            ("presencial", "Presencial"),
            ("virtual", "Virtual"),
            ("hibrida", "Híbrida"),
        ],
        string="Modalidad",
        required=True,
    )

    grupo_formacion = fields.Char(
        string="Grupo de formación",
        required=True,
    )

    tipo_actividad = fields.Selection(
        [
            ("capacitacion", "Capacitación"),
            ("coaching", "Coaching"),
            ("acompanamiento", "Acompañamiento"),
            ("retroalimentacion", "Retroalimentación"),
            ("otro", "Otro"),
        ],
        string="Tipo de actividad",
        required=True,
    )

    formador = fields.Char(
        string="Formador / Responsable",
        required=True,
    )

    campania = fields.Char(
        string="Campaña",
        required=True,
    )

    canal = fields.Char(
        string="Canal",
        required=True,
    )


    # ==========================================================
    # 2. DETALLE DE LA ACTIVIDAD
    # ==========================================================

    tema_contenido = fields.Text(
        string="Tema / Contenido tratado",
        required=True,
    )

    objetivo_actividad = fields.Text(
        string="Objetivo de la actividad",
        required=True,
    )

    metodologia = fields.Selection(
        [
            ("teorica", "Teórica"),
            ("practica", "Práctica"),
            ("taller", "Taller"),
            ("simulacion", "Simulación"),
            ("otro", "Otro"),
        ],
        string="Metodología utilizada",
    )

    recursos_materiales = fields.Text(
        string="Recursos / Materiales utilizados",
    )


    # ==========================================================
    # 3. PARTICIPACIÓN Y ASISTENCIA
    # ==========================================================

    participantes_programados = fields.Integer(
        string="Participantes programados",
        required=True,
    )

    participantes_asistentes = fields.Integer(
        string="Participantes asistentes",
        required=True,
    )

    participantes_ausentes = fields.Integer(
        string="Participantes ausentes",
    )

    porcentaje_asistencia = fields.Float(
        string="% Asistencia",
    )

    registro_asistencia = fields.Binary(
        string="Registro de asistencia",
    )

    registro_asistencia_nombre = fields.Char(
        string="Nombre archivo asistencia",
    )

    observaciones_asistencia = fields.Text(
        string="Observaciones de asistencia",
    )


    # ==========================================================
    # 4. EVALUACIÓN DE LA ACTIVIDAD
    # ==========================================================

    cumplimiento_objetivo = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Cumplimiento del objetivo",
    )

    calidad_actividad = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Calidad de la actividad",
    )

    utilidad_aplicabilidad = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Utilidad / Aplicabilidad",
    )

    comentarios_evaluacion = fields.Text(
        string="Comentarios generales de la evaluación",
    )


    # ==========================================================
    # 5. ESTADO DE EJECUCIÓN
    # ==========================================================

    actividad_ejecutada = fields.Selection(
        [
            ("si", "Sí, ejecutada"),
            ("no", "No ejecutada"),
        ],
        string="¿La actividad fue ejecutada?",
        required=True,
    )

    estado_ejecucion = fields.Selection(
        [
            ("oportuna", "Oportuna"),
            ("retraso", "Con retraso"),
            ("reprogramada", "Reprogramada"),
            ("cancelada", "Cancelada"),
        ],
        string="Estado de ejecución",
        required=True,
    )

    motivo_estado = fields.Selection(
        [
            ("clima", "Condiciones externas"),
            ("operacion", "Necesidad operativa"),
            ("inasistencia", "Inasistencia"),
            ("otro", "Otro"),
        ],
        string="Motivo",
    )

    observaciones_estado = fields.Text(
        string="Observaciones del estado",
    )


    # ==========================================================
    # 6. CIERRE Y REGISTRO
    # ==========================================================

    fecha_registro = fields.Date(
        string="Fecha de registro",
        required=True,
        default=fields.Date.today,
    )

    registrado_por = fields.Char(
        string="Registrado por",
        required=True,
    )

    cargo = fields.Char(
        string="Cargo",
    )

    observaciones_generales = fields.Text(
        string="Observaciones generales",
    )