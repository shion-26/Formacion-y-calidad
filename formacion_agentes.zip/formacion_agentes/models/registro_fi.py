from odoo import api, fields, models
from odoo.exceptions import ValidationError
from datetime import date

class RegistroFI(models.Model):
    _name = "registro_fi"
    _description = "Registro Formación Inicial"

    _sql_constraints = [
        (
            "unique_participant_group",
            "unique(cedula, grupo_formacion_id)",
            "Ya existe un participante registrado con esta cédula en este grupo de formación.",
        ),
    ]

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    # ==========================================================
    # INFORMACIÓN PERSONAL
    # ==========================================================

    cedula = fields.Char(
        string="Cédula / ID",
        required=True,
    )

    nombre = fields.Char(
        string="Nombre completo",
        required=True,
    )

    fecha_nacimiento = fields.Date(
        string="Fecha de nacimiento",
        required=True,
    )

    edad = fields.Integer(
        string="Edad",
        compute="_compute_edad",
        store=True,
        readonly=True,
    )

    genero = fields.Selection(
        [
            ("masculino", "Masculino"),
            ("femenino", "Femenino"),
        ],
        string="Género",
        required=True,
    )

    # ==========================================================
    # INFORMACIÓN ACADÉMICA
    # ==========================================================

    campania_id = fields.Many2one(
        "training.campaign",
        string="Campaña",
        required=True,
    )

    grupo_formacion_id = fields.Many2one(
        "training.group",
        string="Grupo de formación",
        required=True,
    )

    formador_id = fields.Many2one(
        "training.trainer",
        string="Formador",
        required=True,
    )

    tipo_ingreso_id = fields.Many2one(
        "training.entry.type",
        string="Tipo de ingreso",
        required=True,
    )

    numero_grupo = fields.Char(
        string="Número de grupo",
        required=True,
    )

    fecha_ingreso = fields.Date(
        string="Fecha de ingreso",
        required=True,
    )

    # ==========================================================
    # RESULTADO FINAL
    # ==========================================================

    estado_final = fields.Selection(
        [
            ("apto", "Apto"),
            ("abandono", "Abandonó"),
            ("no_inicia", "No inicia"),
            ("renovar", "Por renovar"),
        ],
        string="Concepto final",
        required=True,
    )

    nota_final = fields.Float(
        string="Nota evaluación final",
        help="Valor entre 0 y 100.",
    )

    horas_formacion = fields.Float(
        string="Horas de formación recibidas",
        help="Total de horas cursadas.",
    )

    # ==========================================================
    # OBSERVACIONES
    # ==========================================================

    observaciones = fields.Text(
        string="Observaciones",
    )

    # ==========================================================
    # COMPUTE METHODS
    # ==========================================================

    @api.depends("cedula", "nombre")
    def _compute_name(self):
        for record in self:
            if record.cedula and record.nombre:
                record.name = f"{record.cedula} - {record.nombre}"
            else:
                record.name = ""

    @api.depends("fecha_nacimiento")
    def _compute_edad(self):
        today = fields.Date.today()

        for record in self:
            if record.fecha_nacimiento:
                born = record.fecha_nacimiento
                record.edad = (
                    today.year
                    - born.year
                    - ((today.month, today.day) < (born.month, born.day))
                )
            else:
                record.edad = 0

    @api.constrains(
        "fecha_nacimiento",
        "fecha_ingreso",
        "nota_final",
        "horas_formacion",
    )
    def _check_business_rules(self):
        today = date.today()

        for record in self:

            # Fecha de nacimiento
            if record.fecha_nacimiento:

                if record.fecha_nacimiento > today:
                    raise ValidationError(
                        "La fecha de nacimiento no puede ser futura."
                    )

                if record.edad > 100:
                    raise ValidationError(
                        "La edad del participante parece ser incorrecta."
                    )

            # Fecha de ingreso
            if record.fecha_ingreso:

                if record.fecha_ingreso > today:
                    raise ValidationError(
                        "La fecha de ingreso no puede ser futura."
                    )

            # Nota
            if record.nota_final is not False:

                if record.nota_final < 0:
                    raise ValidationError(
                        "La nota final no puede ser negativa."
                    )

                if record.nota_final > 100:
                    raise ValidationError(
                        "La nota final no puede ser mayor a 100."
                    )

            # Horas
            if record.horas_formacion is not False:

                if record.horas_formacion < 0:
                    raise ValidationError(
                        "Las horas de formación no pueden ser negativas."
                    )
