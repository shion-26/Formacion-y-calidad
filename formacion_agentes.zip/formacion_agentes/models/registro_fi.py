from odoo import fields, models


class RegistroFI(models.Model):
    _name = "registro_fi"
    _description = "Registro Formación Inicial"

    name = fields.Char(
        string="Nombre",
        default="Nuevo",
    )

    # ==========================
    # INFORMACIÓN PERSONAL
    # ==========================

    cedula = fields.Char(
        string="Cédula / ID"
    )

    nombre = fields.Char(
        string="Nombre completo"
    )

    fecha_nacimiento = fields.Date(
        string="Fecha de nacimiento"
    )

    # Temporal mientras diseñamos el formulario.
    # Posteriormente será un campo calculado.
    edad = fields.Char(
        string="Edad"
    )

    genero = fields.Selection(
        [
            ("masculino", "Masculino"),
            ("femenino", "Femenino"),
            ("otro", "Otro"),
        ],
        string="Género",
    )

    # ==========================
    # INFORMACIÓN ACADÉMICA
    # ==========================

    campania = fields.Selection(
        [
            ("generar", "Generar"),
            ("hogar", "Hogar"),
            ("movil", "Móvil"),
            ("t&t", "T&T"),
        ],
        string="Campaña"
    )

    grupo_formacion = fields.Selection(
        [
            ("tmkh", "TMK-H"),
            ("tmkm", "TMK-M"),
            ("t&t", "T&T"),
        ],
        string="Grupo de formación"
    )

    numero_grupo = fields.Selection(
        [(str(i), str(i)) for i in range(1, 51)],
        string="Número de grupo"
    )

    formador = fields.Selection(
        [
            ("formador_1", "ALEJANDRO VASQUEZ VASQUEZ"),
            ("formador_2", "CHRISTIAN ALEJANDRO DAVID MONTAÑO"),
            ("formador_3", "CLARO - JOHN WILLIAM OSSA AZCARATE"),
            ("formador_4", "CLARO - LAURA PATRICIA TARQUINO OCAMPO"),
            ("formador_5", "CLARO - LINA VANESSA COLORADO RESTREPO"),
            ("formador_6", "CRISTHIAN CAMILO AMAYA"),
            ("formador_7", "DIANA KATHERYNE SAENZ GRIJALBA"),
            ("formador_8", "EDITH CAROLINA ARBOLEDA CASTILLO"),
            ("formador_9", "INGRID PAOLA RUIZ LONDOÑO"),
            ("formador_10", "JOHN WILLIM OSSA AZCARATE"),
            ("formador_11", "JORGE HERNAN MOSQUERA SANCHEZ"),
            ("formador_12", "LAURA PATRICIA TARQUINO OCAMPO"),
            ("formador_13", "LAURA VANESSA CAMPOS MONTENEGRO"),
            ("formador_14", "LINA VANESSA COLORADO RESTREPO"),
            ("formador_15", "LUDAIMA YOSELIN PENA NOGUERA"),
            ("formador_16", "MICHEL ANDREA RAIGOZA TRUJILLO"),
            ("formador_17", "MICHELLE ANDREA TIGA OCAMPO"),
            ("formador_18", "NAIARA ISAIOA CASAS CARDENAS"),
            ("formador_19", "STIVEN ALDANA ESCOBAR"),
        ],
        string="Formador asignado"
    )

    fecha_ingreso = fields.Date(
        string="Fecha de ingreso"
    )

    tipo_ingreso = fields.Selection(
        [
            ("normal", "Normal"),
            ("inyeccion", "Inyección"),
        ],
        string="Tipo de ingreso",
    )

    # ==========================
    # ESTADO FINAL
    # ==========================

    estado_final = fields.Selection(
        [
            ("apto", "Apto"),
            ("abandono", "Abandonó"),
            ("no_inicia", "No inicia"),
            ("renovar", "Por renovar"),
        ],
        string="Concepto final",
    )

    nota_final = fields.Float(
        string="Nota evaluación final"
    )

    horas_formacion = fields.Float(
        string="Horas de formación recibidas"
    )

    # ==========================
    # OBSERVACIONES
    # ==========================

    observaciones = fields.Text(
        string="Observaciones"
    )


