from odoo import api, fields, models


class RegistroFI(models.Model):
    _name = "registro_fi"
    _description = "Registro Formación Inicial"

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    # ==========================================================
    # INFORMACIÓN PERSONAL
    # ==========================================================

    cedula = fields.Char(
        string="Cédula / ID",
        required=True,
    )

    nombre = fields.Char(
        string="Nombre completo",
        required=True,
    )

    fecha_nacimiento = fields.Date(
        string="Fecha de nacimiento",
        required=True,
    )

    edad = fields.Integer(
        string="Edad",
        compute="_compute_edad",
        store=True,
        readonly=True,
    )

    genero = fields.Selection(
        [
            ("masculino", "Masculino"),
            ("femenino", "Femenino"),
        ],
        string="Género",
        required=True,
    )

    # ==========================================================
    # INFORMACIÓN ACADÉMICA
    # ==========================================================

    campania_id = fields.Char(
        string="Campaña",
        required=True,
    )

    grupo_formacion_id = fields.Char(
        string="Grupo de formación",
        required=True,
    )

    numero_grupo = fields.Char(
        string="Número de grupo",
        required=True,
        help="Ejemplo: 10",
    )

    formador_id = fields.Char(
        string="Formador asignado",
        required=True,
    )

    fecha_ingreso = fields.Date(
        string="Fecha de ingreso",
        required=True,
    )

    tipo_ingreso = fields.Selection(
        [
            ("normal", "Normal"),
            ("inyeccion", "Inyección"),
        ],
        string="Tipo de ingreso",
        required=True,
    )

    # ==========================================================
    # RESULTADO FINAL
    # ==========================================================

    estado_final = fields.Selection(
        [
            ("apto", "Apto"),
            ("abandono", "Abandonó"),
            ("no_inicia", "No inicia"),
            ("renovar", "Por renovar"),
        ],
        string="Concepto final",
        required=True,
    )

    nota_final = fields.Float(
        string="Nota evaluación final",
        help="Valor entre 0 y 100.",
    )

    horas_formacion = fields.Float(
        string="Horas de formación recibidas",
        help="Total de horas cursadas.",
    )

    # ==========================================================
    # OBSERVACIONES
    # ==========================================================

    observaciones = fields.Text(
        string="Observaciones",
    )

    # ==========================================================
    # COMPUTE METHODS
    # ==========================================================

    @api.depends("cedula", "nombre")
    def _compute_name(self):
        for record in self:
            if record.cedula and record.nombre:
                record.name = f"{record.cedula} - {record.nombre}"
            else:
                record.name = ""

    @api.depends("fecha_nacimiento")
    def _compute_edad(self):
        today = fields.Date.today()

        for record in self:
            if record.fecha_nacimiento:
                born = record.fecha_nacimiento
                record.edad = (
                    today.year
                    - born.year
                    - ((today.month, today.day) < (born.month, born.day))
                )
            else:
                record.edad = 0
