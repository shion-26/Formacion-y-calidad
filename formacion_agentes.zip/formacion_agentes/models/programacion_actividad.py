from odoo import models, fields


class ProgramacionActividad(models.Model):
    _name = "programacion.actividad"
    _description = "Programación de Actividades"

    name = fields.Char(
        string="Registro",
        default="Nueva Programación"
    )