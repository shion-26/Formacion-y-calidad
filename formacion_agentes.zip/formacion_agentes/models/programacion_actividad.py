from odoo import api, fields, models
from odoo.exceptions import ValidationError


class ProgramacionActividades(models.Model):
    _name = "programacion.actividad"
    _description = "Programación de Actividades"

    def action_guardar(self):
        return {
            "type": "ir.actions.client",
            "tag": "reload",
        }

    def action_limpiar(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "view_mode": "form",
            "target": "current",
        }

    # ==================================================
    # REGISTRO
    # ==================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    @api.depends("id_actividad")
    def _compute_name(self):
        for record in self:
            record.name = record.id_actividad or "Nueva actividad"

    # ==================================================
    # 1. INFORMACIÓN GENERAL DE LA ACTIVIDAD
    # ==================================================

    id_actividad = fields.Char(
        string="ID Actividad"
    )

    fecha_programada = fields.Date(
        string="Fecha programada"
    )

    hora_inicio = fields.Char(
        string="Hora inicio programada"
    )

    hora_fin = fields.Char(
        string="Hora fin programada"
    )

    duracion = fields.Char(
        string="Duración programada",
        readonly=True,
        default="hh:mm",
    )

    tipo_actividad = fields.Selection(
        [
            ("induccion", "Inducción"),
            ("formacion", "Formación"),
            ("refuerzo", "Refuerzo"),
            ("coaching", "Coaching"),
            ("retroalimentacion", "Retroalimentación"),
            ("otro", "Otro"),
        ],
        string="Tipo de actividad",
    )

    modalidad = fields.Selection(
        [
            ("presencial", "Presencial"),
            ("virtual", "Virtual"),
            ("hibrida", "Híbrida"),
        ],
        string="Modalidad",
    )

    formador_id = fields.Many2one(
        "training.trainer",
        string="Formador responsable",
    )

    grupo_formacion_id = fields.Many2one(
        "training.group",
        string="Grupo de formación",
    )

    campania_id = fields.Many2one(
        "training.campaign",
        string="Campaña",
    )

    canal = fields.Selection(
        [
            ("voz", "Voz"),
            ("chat", "Chat"),
            ("correo", "Correo"),
        ],
        string="Canal",
    )

    # ==================================================
    # 2. DETALLE DE LA ACTIVIDAD
    # ==================================================

    objetivo = fields.Text(
        string="Objetivo de la actividad"
    )

    contenido = fields.Text(
        string="Contenido / Temas a tratar"
    )

    metodologia = fields.Selection(
        [
            ("teorica", "Teórica"),
            ("practica", "Práctica"),
            ("mixta", "Mixta"),
            ("taller", "Taller"),
            ("simulacion", "Simulación"),
        ],
        string="Metodología",
    )

    recursos = fields.Text(
        string="Recursos / Materiales requeridos"
    )

    # ==================================================
    # 3. PARTICIPANTES PROGRAMADOS
    # ==================================================

    participantes_esperados = fields.Integer(
        string="Participantes esperados"
    )

    grupo_objetivo = fields.Selection(
        [
            ("nuevo_ingreso", "Nuevo ingreso"),
            ("activos", "Activos"),
            ("reentrenamiento", "Reentrenamiento"),
            ("todos", "Todos"),
        ],
        string="Grupo objetivo",
    )

    criterio_seleccion = fields.Text(
        string="Criterio de selección"
    )

    lista_participantes = fields.Binary(
        string="Lista de participantes"
    )

    lista_participantes_nombre = fields.Char(
        string="Nombre del archivo"
    )

    # ==================================================
    # 4. LUGAR / PLATAFORMA
    # ==================================================

    lugar = fields.Selection(
        [
            ("sala", "Sala de capacitación"),
            ("teams", "Microsoft Teams"),
            ("meet", "Google Meet"),
            ("zoom", "Zoom"),
            ("otro", "Otro"),
        ],
        string="Lugar / Plataforma",
    )

    enlace = fields.Char(
        string="Enlace / Ubicación"
    )

    # ==================================================
    # 5. ESTADO Y CONTROL
    # ==================================================

    estado_programacion = fields.Selection(
        [
            ("programada", "Programada"),
            ("revision", "En revisión"),
            ("aprobada", "Aprobada"),
            ("cancelada", "Cancelada"),
        ],
        string="Estado de la programación",
        default="programada",
    )

    registrado_por = fields.Selection(
        [
            ("usuario1", "Usuario 1"),
            ("usuario2", "Usuario 2"),
            ("usuario3", "Usuario 3"),
        ],
        string="Registrado por",
    )

    fecha_registro = fields.Date(
        string="Fecha de registro"
    )

    observaciones = fields.Text(
        string="Observaciones generales"
    )

    # ==================================================
    # 6. CONFIRMACIÓN Y SEGUIMIENTO
    # ==================================================

    fecha_confirmacion = fields.Date(
        string="Fecha de confirmación"
    )

    confirmado_por = fields.Char(
        string="Confirmado por"
    )

    fecha_ejecucion = fields.Date(
        string="Fecha de ejecución real"
    )

    estado_final = fields.Selection(
        [
            ("ejecutada", "Ejecutada"),
            ("reprogramada", "Reprogramada"),
            ("cancelada", "Cancelada"),
            ("no_ejecutada", "No ejecutada"),
        ],
        string="Estado final",
    )

    observaciones_seguimiento = fields.Text(
        string="Observaciones de seguimiento"
    )

    @api.constrains(
        "objetivo",
        "contenido",
        "recursos",
        "criterio_seleccion",
        "observaciones",
        "observaciones_seguimiento",
    )
    def _check_longitud_textos(self):
        campos = [
            ("objetivo", "Objetivo de la actividad"),
            ("contenido", "Contenido / Temas a tratar"),
            ("recursos", "Recursos / Materiales requeridos"),
            ("criterio_seleccion", "Criterio de selección"),
            ("observaciones", "Observaciones generales"),
            ("observaciones_seguimiento", "Observaciones de seguimiento"),
        ]

        for record in self:
            for field_name, label in campos:
                valor = getattr(record, field_name)

                if valor and len(valor) > 500:
                    raise ValidationError(
                        f"El campo '{label}' no puede superar los 500 caracteres."
                    )