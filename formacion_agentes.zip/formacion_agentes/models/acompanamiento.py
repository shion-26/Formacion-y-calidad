from odoo import api, fields, models


class Acompanamiento(models.Model):
    _name = "acompanamiento"
    _description = "Acompañamiento - Monitoreo de Calidad"

    def action_guardar(self):
        return {
            "type": "ir.actions.client",
            "tag": "reload",
        }

    def action_limpiar(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "view_mode": "form",
            "target": "current",
        }

    # ==================================================
    # REGISTRO
    # ==================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    @api.depends("id_monitoreo")
    def _compute_name(self):
        for record in self:
            record.name = record.id_monitoreo or "Nuevo"

    # ==================================================
    # INFORMACIÓN GENERAL
    # ==================================================

    id_monitoreo = fields.Char(
        string="ID Monitoreo"
    )

    fecha_monitoreo = fields.Date(
        string="Fecha del monitoreo"
    )

    hora_inicio = fields.Char(
        string="Hora inicio"
    )

    hora_fin = fields.Char(
        string="Hora fin"
    )

    formador_evaluador_id = fields.Many2one(
        "training.trainer",
        string="Formador / Evaluador",
        related="participante_id.formador_id",
        store=True,
        readonly=True,
    )

    campania_id = fields.Many2one(
        "training.campaign",
        string="Campaña",
    )

    participante_id = fields.Many2one(
        "registro_fi",
        string="Agente evaluado",
    )

    grupo_formacion_id = fields.Many2one(
        "training.group",
        string="Grupo de formación",
        related="participante_id.grupo_formacion_id",
        store=True,
        readonly=True,
    )

    canal_id = fields.Many2one(
        "training.channel",
        string="Canal",
    )

    tipo_interaccion = fields.Selection(
        [
            ("entrada", "Entrada"),
            ("salida", "Salida"),
            ("seguimiento", "Seguimiento"),
        ],
        string="Tipo de interacción",
    )

    id_interaccion = fields.Char(
        string="ID interacción / Contacto"
    )

    # ==================================================
    # EVALUACIÓN DE CALIDAD
    # ==================================================

    score_calidad = fields.Integer(
        string="Score de calidad (%)"
    )

    nivel_calidad = fields.Selection(
        [
            ("excelente", "Excelente"),
            ("bueno", "Bueno"),
            ("regular", "Regular"),
            ("critico", "Crítico"),
        ],
        string="Nivel de calidad",
    )

    resultado_evaluacion = fields.Selection(
        [
            ("aprobado", "Aprobado"),
            ("condicional", "Condicional"),
            ("no_aprobado", "No aprobado"),
        ],
        string="Resultado de la evaluación",
    )

    csat = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="CSAT",
    )

    # ==================================================
    # MÉTRICAS DE GESTIÓN
    # ==================================================

    tiempo_gestion_total = fields.Char(
        string="Tiempo de gestión total"
    )

    tiempo_espera = fields.Char(
        string="Tiempo de espera"
    )

    tiempo_conversacion = fields.Char(
        string="Tiempo de conversación"
    )

    tiempo_post_gestion = fields.Char(
        string="Tiempo de post-gestión"
    )

    tmo = fields.Char(
        string="TMO",
        default="mm:ss",
        readonly=True,
    )

    # ==================================================
    # HALLAZGOS Y ALERTAS
    # ==================================================

    alerta_critica = fields.Selection(
        [
            ("si", "Sí"),
            ("no", "No"),
        ],
        string="¿Se detectaron alertas críticas?",
    )

    cantidad_alertas_criticas = fields.Integer(
        string="Cantidad de alertas críticas"
    )

    cantidad_alertas_menores = fields.Integer(
        string="Cantidad de alertas menores"
    )

    # ==================================================
    # FALLAS DETECTADAS
    # ==================================================

    motivo_falla = fields.Selection(
        [
            ("procedimiento", "Procedimiento"),
            ("comunicacion", "Comunicación"),
            ("sistema", "Sistema"),
            ("otro", "Otro"),
        ],
        string="Motivo de la falla",
    )

    descripcion_fallas = fields.Text(
        string="Descripción de las fallas"
    )

    # ==================================================
    # COACHING / RETROALIMENTACIÓN
    # ==================================================

    fortalezas = fields.Text(
        string="Fortalezas identificadas"
    )

    oportunidades_mejora = fields.Text(
        string="Oportunidades de mejora"
    )

    compromisos_plan_accion = fields.Text(
        string="Compromisos / Plan de acción"
    )

    fecha_seguimiento = fields.Date(
        string="Fecha de seguimiento"
    )