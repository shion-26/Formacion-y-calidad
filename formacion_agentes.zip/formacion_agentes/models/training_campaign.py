from odoo import api, fields, models


class TrainingCampaign(models.Model):
    _name = "training.campaign"
    _description = "Campaña de Formación"

    _sql_constraints = [
        (
            "unique_campaign_name",
            "unique(name)",
            "Ya existe una campaña con ese nombre.",
        ),
    ]

    _order = "name"

    name = fields.Char(
        string="Nombre",
        required=True,
    )

    description = fields.Text(
        string="Descripción",
    )

    group_ids = fields.One2many(
        "training.group",
        "campania_id",
        string="Grupos",
    )

    total_grupos = fields.Integer(
        string="Total grupos",
        compute="_compute_total_grupos",
        store=True,
    )

    @api.depends("group_ids")
    def _compute_total_grupos(self):
        for record in self:
            record.total_grupos = len(record.group_ids)
