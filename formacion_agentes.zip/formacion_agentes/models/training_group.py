from odoo import api, fields, models


class TrainingGroup(models.Model):
    _name = "training.group"
    _description = "Grupo de Formación"
    _order = "fecha_inicio desc, numero_grupo"

    _sql_constraints = [
        (
            "unique_group_campaign",
            "unique(numero_grupo, campania_id)",
            "Ya existe un grupo con ese número para esta campaña.",
        ),
    ]

    # ==========================================================
    # IDENTIFICACIÓN
    # ==========================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
        readonly=True,
    )

    numero_grupo = fields.Char(
        string="Número de grupo",
        required=True,
        help="Ejemplo: 10",
    )

    # ==========================================================
    # INFORMACIÓN GENERAL
    # ==========================================================

    campania_id = fields.Many2one(
        "training.campaign",
        string="Campaña",
        required=True,
    )

    formador_id = fields.Many2one(
        "training.trainer",
        string="Formador",
        required=True,
    )

    fecha_inicio = fields.Date(
        string="Fecha inicio",
        required=True,
    )

    fecha_fin = fields.Date(
        string="Fecha fin",
    )

    tipo_ingreso_id = fields.Many2one(
        "training.entry.type",
        string="Tipo de ingreso",
        required=True,
    )

    estado = fields.Selection(
        [
            ("planeado", "Planeado"),
            ("en_formacion", "En formación"),
            ("finalizado", "Finalizado"),
            ("cancelado", "Cancelado"),
        ],
        string="Estado",
        default="planeado",
        required=True,
    )

    observaciones = fields.Text(
        string="Observaciones",
    )

    # ==========================================================
    # RELACIONES
    # ==========================================================

    participante_ids = fields.One2many(
        "registro_fi",
        "grupo_formacion_id",
        string="Participantes",
    )

    # ==========================================================
    # INDICADORES (Excel)
    # ==========================================================

    total_participantes = fields.Integer(
        string="Total participantes",
        compute="_compute_indicadores",
        store=True,
    )

    total_aptos = fields.Integer(
        string="Total aptos",
        compute="_compute_indicadores",
        store=True,
    )

    porcentaje_certificacion = fields.Float(
        string="% Certificación",
        compute="_compute_indicadores",
        store=True,
    )

    horas_formacion = fields.Float(
        string="Horas de formación",
        compute="_compute_indicadores",
        store=True,
    )

    promedio_evaluacion = fields.Float(
        string="Promedio evaluación",
        compute="_compute_indicadores",
        store=True,
    )

    # ==========================================================
    # COMPUTE METHODS
    # ==========================================================

    @api.depends("campania_id", "numero_grupo")
    def _compute_name(self):
        for record in self:
            if record.campania_id and record.numero_grupo:
                record.name = (
                    f"{record.campania_id.display_name} - Grupo {record.numero_grupo}"
                )
            else:
                record.name = ""

    @api.depends(
        "participante_ids",
        "participante_ids.estado_final",
        "participante_ids.nota_final",
        "participante_ids.horas_formacion",
    )
    def _compute_indicadores(self):
        for record in self:
            participantes = record.participante_ids

            record.total_participantes = len(participantes)

            aptos = participantes.filtered(
                lambda p: p.estado_final == "apto"
            )

            record.total_aptos = len(aptos)

            if record.total_participantes:
                record.porcentaje_certificacion = (
                    record.total_aptos
                    / record.total_participantes
                ) * 100
            else:
                record.porcentaje_certificacion = 0

            record.horas_formacion = sum(
                participantes.mapped("horas_formacion")
            )

            notas = participantes.filtered(
                lambda p: p.nota_final > 0
            )

            if notas:
                record.promedio_evaluacion = (
                    sum(notas.mapped("nota_final"))
                    / len(notas)
                )
            else:
                record.promedio_evaluacion = 0
