from odoo import api, fields, models
from odoo.exceptions import ValidationError


class TrainingGroupSession(models.Model):
    _name = "training.group.session"
    _description = "Grupo de formación real (grupo base + número)"
    _order = "codigo_grupo"
    _rec_name = "codigo_grupo"

    _sql_constraints = [
        (
            "unique_grupo_base_numero",
            "unique(grupo_base_id, numero_grupo)",
            "Ya existe un grupo real registrado con este número para el "
            "grupo base seleccionado.",
        ),
        (
            "unique_codigo_grupo",
            "unique(codigo_grupo)",
            "Ya existe un grupo real registrado con este código.",
        ),
    ]

    grupo_base_id = fields.Many2one(
        "training.group",
        string="Grupo base",
        required=True,
    )

    numero_grupo = fields.Integer(
        string="Número de grupo",
        required=True,
    )

    codigo_grupo = fields.Char(
        string="Código del grupo",
        compute="_compute_codigo_grupo",
        store=True,
    )

    participantes_ids = fields.One2many(
        "registro_fi",
        "grupo_formacion_id",
        string="Participantes",
    )

    # ==========================================================
    # INDICADORES (agregados por grupo real)
    # ==========================================================

    participantes_inscritos = fields.Integer(
        string="Participantes inscritos",
        compute="_compute_indicadores",
        store=True,
    )

    participantes_aptos = fields.Integer(
        string="Participantes aptos",
        compute="_compute_indicadores",
        store=True,
    )

    porcentaje_certificacion = fields.Float(
        string="% Certificados",
        compute="_compute_indicadores",
        store=True,
        aggregator="avg",
    )

    horas_hombre = fields.Integer(
        string="Horas hombre",
        compute="_compute_indicadores",
        store=True,
    )

    promedio_evaluacion = fields.Float(
        string="Promedio de evaluación",
        compute="_compute_indicadores",
        store=True,
        aggregator="avg",
    )

    @api.depends("grupo_base_id", "numero_grupo")
    def _compute_codigo_grupo(self):

        for record in self:

            if record.grupo_base_id and record.numero_grupo:

                record.codigo_grupo = (
                    f"{record.grupo_base_id.name}-{record.numero_grupo}"
                )

            else:

                record.codigo_grupo = False

    @api.depends(
        "participantes_ids.estado_final",
        "participantes_ids.horas_formacion",
        "participantes_ids.nota_final",
    )
    def _compute_indicadores(self):

        for record in self:

            participantes = record.participantes_ids
            inscritos = len(participantes)
            aptos = len(participantes.filtered(lambda p: p.estado_final == "apto"))

            evaluados = self.env["registro_fi"].search(
                [
                    ("id", "in", participantes.ids),
                    ("nota_final", "!=", False),
                ]
            )

            record.participantes_inscritos = inscritos
            record.participantes_aptos = aptos

            record.porcentaje_certificacion = (
                round((aptos / inscritos) * 100) if inscritos else 0.0
            )

            record.horas_hombre = sum(participantes.mapped("horas_formacion"))

            record.promedio_evaluacion = (
                sum(evaluados.mapped("nota_final")) / len(evaluados)
                if evaluados
                else 0.0
            )

    @api.constrains("numero_grupo")
    def _check_numero_grupo(self):
        for record in self:
            if record.numero_grupo <= 0:
                raise ValidationError(
                    "El número de grupo debe ser mayor que cero."
                )
