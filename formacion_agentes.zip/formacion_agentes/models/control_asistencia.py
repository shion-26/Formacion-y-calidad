from odoo import models, fields


class ControlAsistencia(models.Model):
    _name = "control.asistencia"
    _description = "Control de Asistencia"

    name = fields.Char(
        string="Registro",
        default="Nueva Asistencia"
    )