from odoo import api, fields, models


class ControlAsistencia(models.Model):
    _name = "control.asistencia"
    _description = "Control de Asistencia - Formación"

    # ==================================================
    # REGISTRO
    # ==================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    @api.depends("id_sesion")
    def _compute_name(self):
        for record in self:
            record.name = record.id_sesion or "Nueva sesión"

    # ==================================================
    # 1. INFORMACIÓN GENERAL DE LA SESIÓN
    # ==================================================

    id_sesion = fields.Char(
        string="ID Sesión"
    )

    fecha_sesion = fields.Date(
        string="Fecha de la sesión"
    )

    hora_inicio = fields.Char(
        string="Hora inicio"
    )

    hora_fin = fields.Char(
        string="Hora fin"
    )

    duracion = fields.Char(
        string="Duración",
        default="hh:mm",
        readonly=True,
    )

    tipo_sesion = fields.Selection(
        [
            ("induccion", "Inducción"),
            ("formacion", "Formación"),
            ("refuerzo", "Refuerzo"),
            ("coaching", "Coaching"),
            ("retroalimentacion", "Retroalimentación"),
        ],
        string="Tipo de sesión",
    )

    formador = fields.Selection(
        [
            ("formador_1", "ALEJANDRO VASQUEZ VASQUEZ"),
            ("formador_2", "CHRISTIAN ALEJANDRO DAVID MONTAÑO"),
            ("formador_3", "CLARO - JOHN WILLIAM OSSA AZCARATE"),
            ("formador_4", "CLARO - LAURA PATRICIA TARQUINO OCAMPO"),
        ],
        string="Formador",
    )

    grupo_formacion = fields.Selection(
        [
            ("tmkh", "TMK-H"),
            ("tmkm", "TMK-M"),
            ("tyt", "T&T"),
        ],
        string="Grupo de formación",
    )

    canal = fields.Selection(
        [
            ("voz", "Voz"),
            ("chat", "Chat"),
            ("correo", "Correo"),
        ],
        string="Canal",
    )

    campania = fields.Selection(
        [
            ("hogar", "Hogar"),
            ("movil", "Móvil"),
            ("tyt", "T&T"),
        ],
        string="Campaña",
    )

    modalidad = fields.Selection(
        [
            ("presencial", "Presencial"),
            ("virtual", "Virtual"),
            ("hibrida", "Híbrida"),
        ],
        string="Modalidad",
    )

    # ==================================================
    # 2. INFORMACIÓN DEL PARTICIPANTE
    # ==================================================

    participante = fields.Char(
        string="Participante / Agente"
    )

    cedula = fields.Char(
        string="Cédula / ID"
    )

    cargo = fields.Char(
        string="Cargo / Rol"
    )

    fecha_ingreso = fields.Date(
        string="Fecha de ingreso a la campaña"
    )

    antiguedad = fields.Char(
        string="Antigüedad en campaña"
    )

    # ==================================================
    # 3. ASISTENCIA A LA SESIÓN
    # ==================================================

    estado_asistencia = fields.Selection(
        [
            ("asistio", "Asistió"),
            ("no_asistio", "No asistió"),
            ("justificado", "Justificado"),
            ("no_programado", "No programado"),
        ],
        string="Estado de asistencia",
    )

    motivo_inasistencia = fields.Selection(
        [
            ("incapacidad", "Incapacidad"),
            ("permiso", "Permiso"),
            ("vacaciones", "Vacaciones"),
            ("falla_tecnica", "Falla técnica"),
            ("otro", "Otro"),
        ],
        string="Motivo de inasistencia",
    )

    observaciones = fields.Text(
        string="Observaciones"
    )

    # ==================================================
    # 4. DETALLE DE LA SESIÓN
    # ==================================================

    tema = fields.Text(
        string="Tema / Contenido tratado"
    )

    objetivo = fields.Text(
        string="Objetivo de la sesión"
    )

    actividades = fields.Text(
        string="Actividades realizadas"
    )

    material_utilizado = fields.Char(
        string="Material / Recurso utilizado"
    )

    # ==================================================
    # 5. EVALUACIÓN RÁPIDA DE LA SESIÓN
    # ==================================================

    claridad = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Claridad del contenido",
    )

    aplicabilidad = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Aplicabilidad",
    )

    utilidad = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Utilidad",
    )

    participacion = fields.Selection(
        [
            ("1", "1"),
            ("2", "2"),
            ("3", "3"),
            ("4", "4"),
            ("5", "5"),
        ],
        string="Participación del grupo",
    )

    observaciones_formador = fields.Text(
        string="Observaciones del formador"
    )