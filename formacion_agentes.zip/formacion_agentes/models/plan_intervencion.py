from odoo import api, fields, models
from odoo.exceptions import ValidationError


class PlanIntervencion(models.Model):
    _name = "plan_intervencion"
    _description = "Planes de Intervención"

    def action_guardar(self):
        return {
            "type": "ir.actions.client",
            "tag": "reload",
        }

    def action_limpiar(self):
        return {
            "type": "ir.actions.act_window",
            "res_model": self._name,
            "view_mode": "form",
            "target": "current",
        }

    # ==================================================
    # REGISTRO
    # ==================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    @api.depends("id_plan")
    def _compute_name(self):
        for record in self:
            record.name = record.id_plan or "Nuevo"

    # ==================================================
    # INFORMACIÓN GENERAL
    # ==================================================

    id_plan = fields.Char(
        string="ID Plan"
    )

    fecha_creacion = fields.Date(
        string="Fecha de creación"
    )

    campania_id = fields.Many2one(
        "training.campaign",
        string="Campaña",
    )

    participante = fields.Char(
        string="Participante / Agente"
    )

    formador_responsable_id = fields.Many2one(
        "training.trainer",
        string="Formador responsable",
    )

    grupo_formacion_id = fields.Many2one(
        "training.group",
        string="Grupo de formación",
    )

    canal_id = fields.Many2one(
        "training.channel",
        string="Canal",
    )

    tipo_intervencion = fields.Selection(
        [
            ("coaching", "Coaching"),
            ("reentrenamiento", "Reentrenamiento"),
            ("acompanamiento", "Acompañamiento"),
            ("plan_mejora", "Plan de mejora"),
        ],
        string="Tipo de intervención",
    )

    motivo_plan = fields.Selection(
        [
            ("calidad", "Baja calidad"),
            ("alertas", "Alertas críticas"),
            ("tmo", "TMO elevado"),
            ("cliente", "Quejas del cliente"),
            ("otro", "Otro"),
        ],
        string="Motivo del plan",
    )

    # ==================================================
    # DETALLE DEL PLAN
    # ==================================================

    fecha_inicio = fields.Date(
        string="Fecha de inicio"
    )

    fecha_fin_estimada = fields.Date(
        string="Fecha fin estimada"
    )

    fecha_fin_real = fields.Date(
        string="Fecha fin real"
    )

    estado = fields.Selection(
        [
            ("activo", "Activo"),
            ("ejecucion", "En ejecución"),
            ("finalizado", "Finalizado"),
            ("cancelado", "Cancelado"),
        ],
        string="Estado",
        default="activo",
    )

    estado_plan = fields.Selection(
        [
            ("activo", "Activo"),
            ("ejecucion", "En ejecución"),
            ("finalizado", "Finalizado"),
            ("cancelado", "Cancelado"),
        ],
        string="Estado del plan",
        default="activo",
    )

    descripcion_plan = fields.Text(
        string="Descripción del plan"
    )

    horas_planificadas = fields.Integer(
        string="Horas planificadas"
    )

    horas_ejecutadas = fields.Integer(
        string="Horas ejecutadas"
    )

    porcentaje_avance = fields.Integer(
        string="% Avance / Cumplimiento"
    )

    # ==================================================
    # SEGUIMIENTO Y EVALUACIÓN
    # ==================================================

    criterio_evaluacion = fields.Selection(
        [
            ("calidad", "Calidad"),
            ("productividad", "Productividad"),
            ("procedimientos", "Procedimientos"),
            ("integral", "Integral"),
        ],
        string="Criterios de evaluación",
    )

    meta_esperada = fields.Integer(
        string="Meta esperada (%)"
    )

    resultado_obtenido = fields.Integer(
        string="Resultado obtenido (%)"
    )

    porcentaje_cumplimiento = fields.Integer(
        string="% Cumplimiento"
    )

    observaciones_formador = fields.Text(
        string="Observaciones del formador"
    )

    comentarios_participante = fields.Text(
        string="Comentarios del participante"
    )

    evidencias = fields.Binary(
        string="Evidencias"
    )

    evidencias_nombre = fields.Char(
        string="Nombre del archivo"
    )

    acciones_recomendaciones = fields.Text(
        string="Acciones / Recomendaciones"
    )

    # ==================================================
    # CIERRE DEL PLAN
    # ==================================================

    fecha_cierre = fields.Date(
        string="Fecha de cierre"
    )

    motivo_cierre = fields.Selection(
        [
            ("cumplimiento", "Cumplimiento de objetivos"),
            ("retiro", "Retiro del participante"),
            ("cancelado", "Cancelado"),
            ("otro", "Otro"),
        ],
        string="Motivo de cierre",
    )

    resultados_alcanzados = fields.Text(
        string="Resultados alcanzados"
    )

    lecciones_aprendidas = fields.Text(
        string="Lecciones aprendidas"
    )

    @api.constrains(
        "descripcion_plan",
        "observaciones_formador",
        "comentarios_participante",
        "acciones_recomendaciones",
        "resultados_alcanzados",
        "lecciones_aprendidas",
    )
    def _check_longitud_textos(self):
        campos = [
            ("descripcion_plan", "Descripción del plan"),
            ("observaciones_formador", "Observaciones del formador"),
            ("comentarios_participante", "Comentarios del participante"),
            ("acciones_recomendaciones", "Acciones / Recomendaciones"),
            ("resultados_alcanzados", "Resultados alcanzados"),
            ("lecciones_aprendidas", "Lecciones aprendidas"),
        ]

        for record in self:
            for field_name, label in campos:
                valor = getattr(record, field_name)

                if valor and len(valor) > 500:
                    raise ValidationError(
                        f"El campo '{label}' no puede superar los 500 caracteres."
                    )