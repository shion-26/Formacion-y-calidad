from odoo import api, fields, models


class PlanIntervencion(models.Model):
    _name = "plan_intervencion"
    _description = "Planes de Intervención"

    # ==================================================
    # REGISTRO
    # ==================================================

    name = fields.Char(
        string="Nombre",
        compute="_compute_name",
        store=True,
    )

    @api.depends("id_plan")
    def _compute_name(self):
        for record in self:
            record.name = record.id_plan or "Nuevo"

    # ==================================================
    # INFORMACIÓN GENERAL
    # ==================================================

    id_plan = fields.Char(
        string="ID Plan"
    )

    fecha_creacion = fields.Date(
        string="Fecha de creación"
    )

    campania = fields.Selection(
        [
            ("generar", "Generar"),
            ("hogar", "Hogar"),
            ("movil", "Móvil"),
            ("tyt", "T&T"),
        ],
        string="Campaña",
    )

    participante = fields.Char(
        string="Participante / Agente"
    )

    formador_responsable = fields.Selection(
        [
            ("formador_1", "ALEJANDRO VASQUEZ VASQUEZ"),
            ("formador_2", "CHRISTIAN ALEJANDRO DAVID MONTAÑO"),
            ("formador_3", "CLARO - JOHN WILLIAM OSSA AZCARATE"),
            ("formador_4", "CLARO - LAURA PATRICIA TARQUINO OCAMPO"),
        ],
        string="Formador responsable",
    )

    grupo_formacion = fields.Selection(
        [
            ("tmkh", "TMK-H"),
            ("tmkm", "TMK-M"),
            ("tyt", "T&T"),
        ],
        string="Grupo de formación",
    )

    canal = fields.Selection(
        [
            ("voz", "Voz"),
            ("chat", "Chat"),
            ("correo", "Correo"),
        ],
        string="Canal",
    )

    tipo_intervencion = fields.Selection(
        [
            ("coaching", "Coaching"),
            ("reentrenamiento", "Reentrenamiento"),
            ("acompanamiento", "Acompañamiento"),
            ("plan_mejora", "Plan de mejora"),
        ],
        string="Tipo de intervención",
    )

    motivo_plan = fields.Selection(
        [
            ("calidad", "Baja calidad"),
            ("alertas", "Alertas críticas"),
            ("tmo", "TMO elevado"),
            ("cliente", "Quejas del cliente"),
            ("otro", "Otro"),
        ],
        string="Motivo del plan",
    )

    # ==================================================
    # DETALLE DEL PLAN
    # ==================================================

    fecha_inicio = fields.Date(
        string="Fecha de inicio"
    )

    fecha_fin_estimada = fields.Date(
        string="Fecha fin estimada"
    )

    fecha_fin_real = fields.Date(
        string="Fecha fin real"
    )

    estado = fields.Selection(
        [
            ("activo", "Activo"),
            ("ejecucion", "En ejecución"),
            ("finalizado", "Finalizado"),
            ("cancelado", "Cancelado"),
        ],
        string="Estado",
        default="activo",
    )

    estado_plan = fields.Selection(
        [
            ("activo", "Activo"),
            ("ejecucion", "En ejecución"),
            ("finalizado", "Finalizado"),
            ("cancelado", "Cancelado"),
        ],
        string="Estado del plan",
        default="activo",
    )

    descripcion_plan = fields.Text(
        string="Descripción del plan"
    )

    horas_planificadas = fields.Float(
        string="Horas planificadas"
    )

    horas_ejecutadas = fields.Float(
        string="Horas ejecutadas"
    )

    porcentaje_avance = fields.Float(
        string="% Avance / Cumplimiento"
    )

    # ==================================================
    # SEGUIMIENTO Y EVALUACIÓN
    # ==================================================

    criterio_evaluacion = fields.Selection(
        [
            ("calidad", "Calidad"),
            ("productividad", "Productividad"),
            ("procedimientos", "Procedimientos"),
            ("integral", "Integral"),
        ],
        string="Criterios de evaluación",
    )

    meta_esperada = fields.Float(
        string="Meta esperada (%)"
    )

    resultado_obtenido = fields.Float(
        string="Resultado obtenido (%)"
    )

    porcentaje_cumplimiento = fields.Float(
        string="% Cumplimiento"
    )

    observaciones_formador = fields.Text(
        string="Observaciones del formador"
    )

    comentarios_participante = fields.Text(
        string="Comentarios del participante"
    )

    evidencias = fields.Binary(
        string="Evidencias"
    )

    evidencias_nombre = fields.Char(
        string="Nombre del archivo"
    )

    acciones_recomendaciones = fields.Text(
        string="Acciones / Recomendaciones"
    )

    # ==================================================
    # CIERRE DEL PLAN
    # ==================================================

    fecha_cierre = fields.Date(
        string="Fecha de cierre"
    )

    motivo_cierre = fields.Selection(
        [
            ("cumplimiento", "Cumplimiento de objetivos"),
            ("retiro", "Retiro del participante"),
            ("cancelado", "Cancelado"),
            ("otro", "Otro"),
        ],
        string="Motivo de cierre",
    )

    resultados_alcanzados = fields.Text(
        string="Resultados alcanzados"
    )

    lecciones_aprendidas = fields.Text(
        string="Lecciones aprendidas"
    )