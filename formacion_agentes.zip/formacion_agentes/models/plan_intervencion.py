from odoo import models, fields


class PlanIntervencion(models.Model):
    _name = "plan.intervencion"
    _description = "Plan de Intervención"

    name = fields.Char(
        string="Registro",
        default="Nuevo Plan"
    )