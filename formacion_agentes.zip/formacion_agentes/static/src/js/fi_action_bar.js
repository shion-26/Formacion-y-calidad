/** @odoo-module **/
import { registry } from "@web/core/registry";
import { Component } from "@odoo/owl";

export class FiActionBar extends Component {
    static template = "formacion_agentes.FiActionBar";
    static props = ["*"];

    async onClickGuardar() {
        // Idéntico al botón Guardar nativo: valida constrains,
        // crea o actualiza el registro, y permanece sobre el mismo registro.
        await this.props.record.save();
    }

    async onClickLimpiar() {
        const resModel = this.props.record.resModel;

        // Descarta cambios sin guardar (no-op si no hay cambios).
        await this.props.record.discard();

        // Reemplaza la acción actual por una acción nueva y vacía
        // sobre el mismo modelo: equivalente exacto a "abrir un
        // formulario completamente nuevo".
        await this.env.services.action.doAction({
            type: "ir.actions.act_window",
            res_model: resModel,
            views: [[false, "form"]],
            target: "current",
        });
    }
}

registry.category("view_widgets").add("fi_action_bar", {
    component: FiActionBar,
});
