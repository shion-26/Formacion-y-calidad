# Análisis Funcional — Libro 5: Programación de Actividades
### Módulo `formacion_agentes` — Odoo 18

**Fuentes revisadas:**
- `Requerimientos generales DATOS.pdf` (6 libros, fórmulas oficiales).
- `CONTROL GENERAL FORMACIÓN...xlsx`, hoja **"7. PROGRAMACIÓN DE ACTIVIDADES"** (768 filas reales de datos históricos) y hoja **"LISTAS DESPLEGABLE E INFO"** (catálogos oficiales de listas desplegables).
- Mockup del formulario (imagen entregada).
- Código actual: `models/programacion_actividad.py`, `views/programacion_actividad_views.xml`, y los modelos hermanos ya construidos (`registro_fi`, `acompanamiento`, `plan_intervencion`, `control_asistencia`, `actividad_ejecutada`, catálogos `training.*`).

Convención usada en todo el documento:
- 🟢 **PDF** = lo pide explícitamente el documento de requerimientos.
- 🔵 **Excel** = existe/se comporta así en la hoja real de datos históricos.
- 🟠 **Mockup/Modelo** = está en el formulario y/o en `programacion_actividad.py` pero no tiene respaldo en PDF ni Excel.
- 🟣 **Mejora propuesta** = sugerencia mía, no solicitada por el cliente.

---

## Resumen ejecutivo de hallazgos críticos

1. **El estado del formulario no coincide con el estado que pide el PDF.** El PDF define para el Libro 5 los estados *Programada / Ejecutada / Reprogramada / Cancelada*. El modelo actual (`estado_programacion`) implementa en cambio un flujo de aprobación *Programada / En revisión / Aprobada / Cancelada* que no existe ni en el PDF ni en el Excel.
2. **La sección "6. Confirmación y seguimiento" duplica el propósito del Libro 6 (Actividades Ejecutadas).** El PDF pide explícitamente **6 bases de datos separadas** (recomendación textual al final del documento), y el proyecto ya construyó `actividad.ejecutada` como modelo independiente. Tener `fecha_ejecucion` y `estado_final` (ejecutada/reprogramada/cancelada/no_ejecutada) dentro de Programación reintroduce la mezcla que el Excel real sí tiene (una sola hoja con columnas de programado + ejecutado) pero que el PDF pidió separar.
3. **No existe relación (Many2one) entre `programacion.actividad` y `actividad.ejecutada`.** Ambos modelos tienen su propio `id_actividad` como texto libre, sin vínculo real. Sin esa relación, indicadores como **Puntualidad** y **% Programado** no se pueden calcular de forma confiable (ver sección 7).
4. **Los catálogos de valores de `tipo_actividad` y `canal` no corresponden a los valores reales del negocio.** El Excel (hoja de listas desplegables) define oficialmente: `Tipo de actividad programada` = {ADMINISTRATIVA, FORMACIÓN INICIAL, INTERVENCIÓN FORMATIVA ESPECÍFICA, PLAN DE INTERVENCIÓN FORMATIVA} y `Canal` = {IN Y OUT, INBOUND, OUTBOUND}. El modelo actual usa selecciones inventadas (`induccion/formacion/refuerzo/coaching/retroalimentacion/otro` y `voz/chat/correo`) que no aparecen en ninguna fuente.
5. **El campo "Duración programada" no está calculado.** El campo `duracion` es `Char`, `readonly=True`, con `default="hh:mm"`, pero **no tiene ningún `@api.depends` ni método `compute`**. Hoy simplemente nunca se llena. Además, al ser texto, no podría sumarse para el indicador "Horas programadas" aunque se calculara.
6. **`canal` no sigue el patrón ya establecido en el módulo.** `acompanamiento`, `plan_intervencion` y `control_asistencia` usan `canal_id` como `Many2one` a `training.channel`. `programacion.actividad` y `actividad.ejecutada` usan `canal` como `Selection`/`Char` de texto libre — inconsistencia arquitectónica dentro del mismo módulo.
7. **La sección "3. Participantes programados" y "4. Lugar/Plataforma" no tienen respaldo en el Excel ni en el PDF**, salvo el número de participantes (columna `POBLACIÓN OBJETIVO #`, vacía en el 61% de los 768 registros históricos).

Estos siete puntos condicionan buena parte de las respuestas de las secciones siguientes.

---

## 1. Comprensión del proceso de negocio

**¿Qué representa este libro?**
Según el PDF, el Libro 5 es el libro de **planeación** ("Programación de Actividades — Planeación"): registra, antes de que ocurra, qué actividad de formación/intervención se va a realizar, cuándo, con qué formador, para qué campaña/canal y con qué duración prevista. Es un libro de **intención**, no de ejecución.

El Excel confirma esto en su hoja real, aunque de forma **incompleta respecto al ideal del PDF**: la hoja "7. PROGRAMACIÓN DE ACTIVIDADES" mezcla en cada fila tanto la fecha programada como la fecha de ejecución real y si se ejecutó u no, es decir, en la práctica el cliente **ha estado operando la planeación y el seguimiento de ejecución como una sola cosa**, aunque el PDF pide separarlos en dos libros (5 y 6).

**Objetivo dentro de Formación Inicial:**
Formación Inicial (Libro 1) es el proceso de ingreso/certificación de agentes nuevos. Programación de Actividades es el mecanismo operativo que **agenda las sesiones de formación, coaching, refuerzo e intervención** que sostienen ese proceso (y también sostiene el ciclo de vida de agentes activos, no solo nuevos — el Excel real tiene actividades de tipo "ADMINISTRATIVA" y "PLAN DE INTERVENCIÓN FORMATIVA" que no son exclusivas de formación inicial).

**Actores:**
- **Formador**: responsable de dictar la actividad (`training.trainer`, ya existe).
- **Quien programa/registra**: el PDF no lo detalla como dato explícito del Libro 5; el mockup sí lo agrega (`registrado_por`, `confirmado_por`) — ver sección 8.
- **Agentes/participantes**: aparecen solo como cantidad esperada (Excel) o como grupo objetivo (mockup), no como registros individuales vinculados — el detalle individual de quién asistió vive en el Libro 4 (`control.asistencia`).

**Qué información registra vs. qué solo alimenta indicadores:**
- Registra: identidad de la actividad, cuándo, quién, para quién (campaña/canal/grupo), duración prevista, estado.
- Solo alimenta indicadores (no es información "de la actividad" en sí): duración agregada (horas programadas), conteos por estado, fecha de referencia para "actividades por día".

**Relación con los demás libros:**

| Libro | Relación real hoy en el código | Relación esperada según PDF |
|---|---|---|
| Registro FI (Libro 1) | Ninguna relación directa. `programacion.actividad` no referencia `registro_fi`. | El PDF no pide vincular Programación a inscritos individuales; la población es agregada (`Población objetivo #`), así que esto es coherente. |
| Acompañamiento (Libro 2) | Ninguna. `acompanamiento` se relaciona con `registro_fi`, no con `programacion.actividad`. | El PDF tampoco pide esta relación explícitamente. |
| Planes de Intervención (Libro 3) | Ninguna. | No solicitada por el PDF. |
| Control de Asistencia (Libro 4) | Ninguna, aunque conceptualmente una "sesión" de asistencia y una "actividad programada" son el mismo evento visto desde dos ángulos (formador, grupo, canal, fecha). Hoy son dos identificadores de texto independientes (`id_sesion` vs `id_actividad`). | El PDF no pide la relación explícitamente, pero es la brecha estructural más relevante del módulo completo si se quiere trazabilidad real planeación→asistencia. |
| Actividades Ejecutadas (Libro 6) | **Debería ser la relación más fuerte** (una actividad ejecutada cumple una actividad programada), pero **no existe ningún campo de relación** entre `programacion.actividad` y `actividad.ejecutada`. | El PDF los define como libros separados pero relacionados conceptualmente (misma "actividad", dos momentos). Sin relación, los indicadores de puntualidad/cumplimiento del Libro 5 no son calculables (ver sección 7). |

---

## 2 y 3. Análisis y clasificación de cada campo del formulario

Categorías usadas (según lo pedido): Captura manual · Related · Calculado · Derivado · Catálogo · Configuración · Indicador · Control del proceso · Seguimiento · Cierre.

### Sección 1 — Información general de la actividad

| Campo | Propósito | Fuente | Clasificación | ¿Obligatorio? | Observación |
|---|---|---|---|---|---|
| **ID Actividad** | Identificar unívocamente la actividad | 🟢PDF (campo pedido) / 🔵Excel no tiene un ID explícito, identifica actividades por fecha+texto | Captura manual (hoy) | Sí, según PDF | El PDF lo pide pero el Excel real **no tiene un ID de actividad como tal**; no hay ninguna columna equivalente. Hoy en el modelo es un `Char` libre sin `unique` ni secuencia — inconsistente con `id_monitoreo` (Acompañamiento) e `id_sesion` (Asistencia), que sí tienen restricción `unique` + normalización. Esto debe decidirse con el cliente: ¿ID manual con formato libre, o secuencia automática tipo `ACT-000123` como sugiere el placeholder? |
| **Fecha programada** | Cuándo se planea la actividad | 🟢PDF 🔵Excel (`FECHA PROGRAMADO`) | Captura manual | Sí | Campo sólido, respaldado por ambas fuentes. |
| **Hora inicio / Hora fin programada** | Definir la ventana horaria | 🟠Mockup/Modelo — **no existe en el PDF ni en el Excel** | Captura manual | El mockup lo marca obligatorio, pero no está pedido | El Excel solo registra minutos totales (`TIEMPO PROGRAMADO (MINUTOS)`), no horas de inicio/fin. Es una mejora razonable para poder detectar "puntualidad" en el futuro, pero **hoy no se usa para nada** (ni siquiera para calcular `duracion`, ver más abajo) — captura muerta actualmente. |
| **Duración programada** | Medir tiempo total de la actividad | 🟢PDF (pide "Duración") 🔵Excel (`TIEMPO PROGRAMADO (MINUTOS)`, numérico) | Debería ser **Calculado**, hoy es un campo `Char` estático sin `compute` | Sí | **Bug de diseño**: el campo se muestra deshabilitado (implica cálculo automático) pero no hay ningún método que lo calcule a partir de hora inicio/fin. Además, al ser texto `hh:mm`, no es sumable para el indicador "Horas programadas" — el Excel usa minutos numéricos precisamente para poder sumarlos. |
| **Tipo de actividad** | Clasificar la naturaleza de la actividad | 🟢PDF (pide el campo) 🔵Excel tiene catálogo oficial: ADMINISTRATIVA / FORMACIÓN INICIAL / INTERVENCIÓN FORMATIVA ESPECÍFICA / PLAN DE INTERVENCIÓN FORMATIVA | Catálogo | Sí | Los valores actuales del modelo (`induccion/formacion/refuerzo/coaching/retroalimentacion/otro`) **no corresponden a ningún valor real del negocio**. Tampoco coinciden con los valores usados en `actividad.ejecutada.tipo_actividad` (`capacitacion/coaching/acompanamiento/retroalimentacion/otro`) — ni siquiera los dos libros hermanos usan el mismo catálogo entre sí. |
| **Modalidad** | Presencial/virtual/mixta | 🔵Excel tiene catálogo oficial "METODOLOGÍA" = {PRESENCIAL, VIRTUAL, MIXTA} | Catálogo | El mockup lo marca obligatorio; el PDF no lo pide para este libro | El valor `hibrida` del modelo no coincide textualmente con `MIXTA` del catálogo real (aunque el concepto es el mismo). Además, curiosamente el Excel llama a esto "METODOLOGÍA", mientras que el mockup usa ese mismo nombre para otro campo distinto (ver sección 2 del formulario) — riesgo de confusión conceptual entre "modalidad" y "metodología" que conviene aclarar con el cliente. |
| **Formador responsable** | Quién dicta | 🟢PDF 🔵Excel | Related/Catálogo (`Many2one training.trainer`) | Sí | Correctamente modelado como relación a catálogo, coherente con el resto del módulo. |
| **Grupo de formación** | A qué grupo aplica | 🟠Mockup/Modelo — el PDF no lo pide para este libro (sí lo pide para Asistencia/Registro) y el Excel real de Programación tampoco tiene esta columna | Related/Catálogo (`Many2one training.group`) | El mockup lo marca obligatorio, sin respaldo documental | Es razonable si la actividad se dirige a un grupo formal, pero el histórico del Excel muestra que **la mayoría de actividades programadas no se ligan a un grupo puntual** sino a un formador/campaña en general (muchas son "ADMINISTRATIVA" o "PLAN DE INTERVENCIÓN FORMATIVA", no sesiones de grupo). Forzarlo como obligatorio podría no encajar con el dato real. |
| **Campaña** | Para qué campaña aplica | 🟢PDF 🔵Excel (HOGAR/GENERAL/MÓVIL/T&T) | Related/Catálogo (`Many2one training.campaign`) | Sí | Bien modelado y consistente con el resto del módulo. |
| **Canal** | Canal de la operación | 🟢PDF 🔵Excel catálogo oficial {IN Y OUT, INBOUND, OUTBOUND} | Debería ser Related/Catálogo | Sí | Hoy es `Selection` de texto libre (`voz/chat/correo`), **valores que no existen en ningún dato real**, y además **no sigue el patrón `canal_id → training.channel`** que ya usan Acompañamiento, Planes de Intervención y Control de Asistencia. Esta es la inconsistencia más clara del módulo. |

### Sección 2 — Detalle de la actividad

| Campo | Propósito | Fuente | Clasificación | Obligatorio | Observación |
|---|---|---|---|---|---|
| **Objetivo de la actividad** | Qué se busca lograr | 🟠Mockup/Modelo. El Excel tiene una única columna de texto libre `ACTIVIDAD PROGRAMADA` que mezcla objetivo+contenido en un solo campo (ej: *"Actualizar PCAM 1045... con descuento del 100%..."*) | Captura manual | Sí (mockup) | El PDF no pide "objetivo" como campo separado para este libro. Partir la descripción libre del Excel en "Objetivo" + "Contenido" es una mejora de estructuración razonable, pero **no está pedida explícitamente**; debe validarse con el cliente si de verdad diligenciarán dos campos separados o seguirán escribiendo un solo texto libre como hoy. |
| **Contenido / Temas a tratar** | Qué se va a tratar | 🟠Mockup/Modelo (ver arriba) | Captura manual | Sí (mockup) | Igual observación que Objetivo. |
| **Metodología** | Cómo se ejecuta pedagógicamente | 🟠Mockup/Modelo — no aparece como catálogo separado en la hoja de listas desplegables (el único catálogo llamado "METODOLOGÍA" en el Excel real es PRESENCIAL/VIRTUAL/MIXTA, que el modelo ya usa como "Modalidad") | Catálogo (pero inventado) | No obligatorio | Los valores actuales (`teorica/practica/mixta/taller/simulacion`) **no tienen respaldo en ninguna fuente entregada**. Es probablemente una confusión de nombres con el campo "Modalidad" (ver hallazgo de la sección 1). Debe aclararse con el cliente si esto es un campo real distinto o una duplicación conceptual. |
| **Recursos / Materiales requeridos** | Qué se necesita para dictarla | 🟠Mockup/Modelo, sin respaldo en PDF/Excel | Captura manual | No | Campo razonable operativamente pero no solicitado; no aporta a ningún indicador. |

### Sección 3 — Participantes programados

| Campo | Propósito | Fuente | Clasificación | Obligatorio | Observación |
|---|---|---|---|---|---|
| **Participantes esperados** | Cuántas personas se esperan | 🔵Excel parcial: `POBLACIÓN OBJETIVO #`, presente solo en 301 de 768 filas históricas (39%) | Captura manual | El mockup lo marca obligatorio | El dato existe en el Excel pero **el propio histórico muestra que casi nunca se diligencia** (61% vacío). Antes de volverlo obligatorio en Odoo hay que confirmar con el cliente si realmente se compromete a llenarlo siempre, o si seguirá siendo opcional como ha sido en la práctica. |
| **Grupo objetivo** | Nuevo ingreso / activos / reentrenamiento / todos | 🟠Mockup/Modelo, sin ninguna columna equivalente en Excel ni mención en PDF | Captura manual (catálogo inventado) | Sí (mockup) | Sin respaldo documental. No aparece en ninguna de las 88 columnas de catálogos oficiales del Excel. |
| **Criterio de selección** | Cómo se eligió a los participantes | 🟠Mockup/Modelo, sin respaldo | Captura manual | No | Sin respaldo documental ni en PDF ni Excel. |
| **Lista de participantes (archivo)** | Adjuntar lista | 🟠Mockup/Modelo, sin respaldo (aunque `plan_intervencion.evidencias` ya usa un patrón equivalente de adjunto Excel/CSV ≤5MB) | Captura manual (archivo) | No | Consistente técnicamente con el patrón ya usado en Planes de Intervención, pero no solicitado para este libro. |

### Sección 4 — Lugar / Plataforma

| Campo | Propósito | Fuente | Clasificación | Obligatorio | Observación |
|---|---|---|---|---|---|
| **Lugar / Plataforma** | Sala física o plataforma virtual | 🟠Mockup/Modelo, sin ninguna columna equivalente en Excel ni PDF | Catálogo (inventado) | Sí (mockup) | Ninguna fuente respalda esta sección completa. Podría justificarse operativamente (saber si es Teams/Zoom/sala), pero es una decisión de diseño, no un requerimiento del cliente. |
| **Enlace / Ubicación** | Link o dirección física | 🟠Mockup/Modelo, sin respaldo | Captura manual | No | Igual que el anterior. |

### Sección 5 — Estado y control

| Campo | Propósito | Fuente | Clasificación | Obligatorio | Observación |
|---|---|---|---|---|---|
| **Estado de la programación** | Ciclo de vida de la actividad | 🟢PDF pide 4 estados: *Programada / Ejecutada / Reprogramada / Cancelada* | Control del proceso | Sí | **El modelo actual no implementa los estados del PDF.** Implementa en su lugar un flujo de aprobación (*Programada / En revisión / Aprobada / Cancelada*) que no aparece ni en el PDF ni en el Excel. Esto es una decisión de diseño de la persona que armó el mockup, no un requerimiento del cliente, y **rompe directamente la fórmula "% Programado"**, que asume que el estado puede tomar el valor "Ejecutada" (dato que en el modelo actual solo vive en el otro libro, `actividad.ejecutada`). |
| **Registrado por** | Quién digitó el registro | 🟠Mockup/Modelo. El PDF no lo pide para este libro. | Captura manual (hoy hardcodeado) | Sí (mockup) | Está implementado como `Selection` fija con **usuarios ficticios** (`usuario1/usuario2/usuario3`), claramente un placeholder de desarrollo nunca completado. El propio módulo ya tiene el patrón correcto para esto: `registro_fi.usuario_resumen`, calculado desde `create_uid`. Esto debe corregirse independientemente de si se decide mantener el campo. |
| **Fecha de registro** | Cuándo se digitó | 🟠Mockup/Modelo, sin respaldo explícito en PDF | Debería ser Derivado (`create_date`) | Sí (mockup) | Hoy es una fecha de captura manual editable, cuando conceptualmente es un dato de auditoría del sistema (Odoo ya guarda `create_date` automáticamente en todo modelo). |
| **Observaciones generales** | Notas libres | 🔵Excel tiene `OBSERVACIONES` | Captura manual | No | Buen respaldo, coincide con el Excel real. |

### Sección 6 — Confirmación y seguimiento (marcada en el propio mockup como "para uso posterior")

| Campo | Propósito | Fuente | Clasificación | Obligatorio | Observación |
|---|---|---|---|---|---|
| **Fecha de confirmación** | Cuándo se confirmó que se haría | 🟠Mockup/Modelo, sin respaldo | Seguimiento | No | Sin respaldo en PDF/Excel; concepto plausible pero no solicitado. |
| **Confirmado por** | Quién confirmó | 🟠Mockup/Modelo, `Char` libre | Seguimiento | No | Igual observación que "Registrado por": debería ser un usuario del sistema, no texto libre, si se mantiene. |
| **Fecha de ejecución real** | Cuándo ocurrió realmente | 🟢PDF, pero **para el Libro 6**, no el Libro 5 | Cierre — **pertenece al otro libro** | No | Esto es exactamente el campo `fecha_ejecucion` que ya existe en `actividad.ejecutada`. Tenerlo duplicado aquí reintroduce la mezcla planeación/ejecución que el Excel real tiene y que el PDF pidió separar. |
| **Estado final** | Ejecutada / Reprogramada / Cancelada / No ejecutada | 🟢PDF, también para el **Libro 6**, no el 5 | Cierre — **pertenece al otro libro** | No | Misma observación. Es prácticamente el mismo concepto que `actividad.ejecutada.actividad_ejecutada` + `estado_ejecucion`, ya modelados allá. |
| **Observaciones de seguimiento** | Notas de cambios posteriores | 🟠Mockup/Modelo, sin respaldo | Seguimiento | No | Razonable como bitácora, pero redundante con `observaciones_estado` de `actividad.ejecutada`. |

**Conclusión de la sección 6:** toda esta sección del formulario compite funcionalmente con el Libro 6 ya construido. Es el hallazgo más importante para decidir antes de tocar código: **¿Programación de Actividades debe "cerrar" su propio ciclo, o el cierre siempre ocurre en Actividades Ejecutadas y Programación solo enlaza hacia allá?** El PDF, al pedir 6 bases separadas, sugiere la segunda opción.

---

## 4. Relaciones entre modelos — qué debería ser `related`, `compute` o manual

| Dato | Hoy | Debería ser | Por qué |
|---|---|---|---|
| Formador | `Many2one` manual a `training.trainer` | Correcto tal cual | Es información propia de la actividad (quién la dicta), no se deriva de otro registro. |
| Campaña | `Many2one` manual a `training.campaign` | Correcto tal cual | Igual razón. |
| Canal | `Selection` de texto libre | `Many2one` manual a `training.channel` | Para seguir el mismo patrón que `acompanamiento.canal_id`, `plan_intervencion.canal_id`, `control_asistencia.canal_id`, y para que los valores reales (IN Y OUT/INBOUND/OUTBOUND) puedan mantenerse centralizados en un catálogo en vez de repetirse en cada `Selection` del módulo. |
| Grupo de formación | `Many2one` manual a `training.group` | Correcto en el tipo de campo; a validar si debe ser obligatorio (ver sección 2). | — |
| Usuario que registra | `Selection` fija ficticia | `related`/`compute` desde `create_uid`, igual que `registro_fi.usuario_resumen` | Es información que Odoo ya conoce automáticamente; no tiene sentido pedirle al usuario que la escoja de una lista de 3 nombres fijos. |
| Fecha de registro | Captura manual | `compute` desde `create_date`, igual que `registro_fi.fecha_resumen` | Mismo argumento — es un dato de auditoría del sistema, no una decisión del usuario. |
| Duración programada | `Char` estático sin cálculo | `compute` numérico (minutos u horas decimales) a partir de hora inicio/fin, `store=True` para poder sumarlo en indicadores | Ver hallazgo #5 del resumen ejecutivo. El patrón ya existe en el módulo: `control_asistencia._compute_duracion` calcula duración a partir de `hora_inicio`/`hora_fin` con validación de formato — es el ejemplo a seguir, aunque ese método produce texto ("2 horas y 30 minutos"), útil para mostrar pero no para sumar. Para que "Horas programadas" sea sumable, se necesita **además** un campo numérico. |
| Nombre técnico del registro (`name`) | `compute` desde `id_actividad` | Correcto tal cual, sigue el patrón de todos los libros hermanos. | — |

**Participantes:** el PDF no pide vincular participantes individuales (`registro_fi`) a la Programación — solo un número esperado. Por lo tanto no corresponde crear una relación `One2many`/`Many2many` a `registro_fi` a menos que el cliente lo pida explícitamente; hacerlo sería una mejora no solicitada, no una necesidad funcional confirmada.

---

## 5. Reglas de negocio por sección

**Fechas**
- Obligatoria: la fecha programada no debería poder ser tan lejana en el pasado que contradiga el propósito de "planeación" (el resto del módulo sí valida "no fechas futuras" para fechas de hecho consumado — aquí es al revés: es una fecha de plan, por lo que "no futura" NO debería aplicar, a diferencia de `fecha_monitoreo`, `fecha_sesion`, `fecha_nacimiento`, etc., que sí validan esto en los otros modelos).
- Solo calidad de datos: fecha de registro no debería ser anterior a la fecha programada, si se decide mantenerla como campo separado.

**Horarios**
- Obligatoria si se mantienen hora inicio/fin: formato `HH:MM` válido y hora fin posterior a hora inicio — el módulo ya tiene el regex `HORA_RE` reutilizado en `acompanamiento.py` y `control_asistencia.py`; debería aplicarse igual aquí si el campo se conserva.
- Hoy no existe ninguna validación sobre `hora_inicio`/`hora_fin` en `programacion_actividad.py`, a diferencia de sus pares.

**Duración**
- Debe ser positiva y coherente con hora inicio/fin (si se calculan de esa forma), igual que en `control_asistencia`.
- Regla de calidad, no bloqueante: rangos "razonables" (ej. no permitir 0 minutos ni duraciones de varios días) — el cliente no ha definido un tope, así que no debe inventarse uno como validación dura.

**Estados y transiciones**
- Obligatoria (pendiente de definición con cliente): decidir el conjunto de estados real de este libro. Si se adopta el del PDF (Programada/Ejecutada/Reprogramada/Cancelada), hay que decidir si "Ejecutada" se marca manualmente aquí o se deriva automáticamente cuando existe una `actividad.ejecutada` vinculada — que hoy no existe la relación para poder derivarlo.
- Ninguna transición está validada hoy en el código: los botones de estado (`estado_programacion_buttons.js`, `estado_final_actividad_buttons.js`) permiten saltar libremente entre cualquier estado sin restricción de flujo (a diferencia, por ejemplo, de las reglas condicionales que sí existen en `acompanamiento` para alertas críticas, o en `control_asistencia` para motivo de inasistencia).

**Participantes**
- Solo calidad de datos: participantes esperados no debería ser negativo (no validado hoy).
- El histórico muestra que este dato casi nunca se diligencia (39% de registros), por lo que forzar su obligatoriedad es una decisión de negocio que debe confirmarse, no asumirse.

**Modalidad / Lugar**
- Regla de calidad razonable si se mantiene "Lugar/Plataforma": coherencia entre modalidad "Presencial" y un lugar físico, o "Virtual" y un enlace — no está pedida por el cliente, sería una mejora.

**Textos largos**
- Ya implementado consistentemente (`_check_longitud_textos`, límite de 500 caracteres), igual patrón que en todos los libros hermanos. Correcto y a mantener.

---

## 6. Automatizaciones posibles (sin código, solo lógica)

- **Duración**: calcular automáticamente a partir de hora inicio/fin (como ya hace `control_asistencia`), y almacenar también un valor numérico (minutos) para que sea sumable.
- **Usuario y fecha de registro**: derivar automáticamente de `create_uid`/`create_date`, eliminando la necesidad de que el usuario los diligencie manualmente (patrón ya usado en `registro_fi`).
- **Nombre técnico del registro**: ya automatizado vía `id_actividad` (correcto, sin cambios).
- **Estado "Ejecutada" del Libro 5**: si se crea la relación con `actividad.ejecutada`, este estado podría derivarse automáticamente (si existe una ejecución vinculada, el estado pasa a "Ejecutada") en lugar de depender de que alguien lo actualice manualmente en dos lugares distintos.
- **Puntualidad**: solo automatizable si existen ambos datos comparables: hora de inicio *programada* (Libro 5) y hora de inicio *real* (Libro 6, que ya existe como `hora_inicio_real`) más la relación entre ambos registros. Hoy falta esa relación.
- **Indicadores agregados** (Total programadas, Horas programadas, % Programado): son cálculos de agregación sobre el conjunto de registros, no campos individuales — se resuelven mejor con vistas de reporte/pivote (como ya hace el propio Excel con sus hojas "TD") que con campos `compute` dentro de cada registro.

No se identifican automatizaciones "mágicas" adicionales no mencionadas por el cliente — cualquier otra (por ejemplo, notificaciones automáticas al formador, recordatorios) no tiene respaldo en el PDF ni el Excel y no debe asumirse.

---

## 7. Análisis de los indicadores solicitados

| Indicador | Fórmula (PDF) | Datos que requiere | ¿Calculable hoy? | Limitación |
|---|---|---|---|---|
| **Total actividades programadas** | Contar actividades | Ninguno adicional, es el conteo de registros | Sí | Trivial una vez exista el modelo con datos. |
| **Horas programadas** | Suma de duración | Duración **numérica** por actividad | **No, hoy no** | `duracion` es texto sin calcular (hallazgo #5). Se resuelve corrigiendo el campo (ver sección 6). |
| **Actividades promedio por día** | Total actividades / número de días | Total de actividades + "número de días" | Parcialmente — **ambigüedad no resuelta por el cliente** | El PDF no define qué es "número de días": ¿días del rango de fechas filtrado, ¿días distintos con al menos una actividad?, ¿días hábiles del mes? Esto se resuelve normalmente en un reporte con filtro de período, no como campo del formulario, pero requiere que el cliente defina la regla exacta. |
| **% Programado** | (Programadas / Total) × 100 | Conteo de registros en estado "Programada" sobre el total | Sí, **una vez se resuelva el hallazgo #1** (el estado actual del modelo no tiene un valor "Programada" comparable de forma consistente con "Total", porque no hay un valor "Ejecutada" en este mismo libro que dé sentido al contraste). |
| **Puntualidad** | (Iniciadas a tiempo / Ejecutadas) × 100 | Actividades ejecutadas + si iniciaron a tiempo, comparando hora programada vs. hora real | **No calculable con la información actualmente disponible** | Requiere: (a) relación entre `programacion.actividad` y `actividad.ejecutada` (no existe), y (b) hora de inicio real comparable con hora de inicio programada. El proxy más cercano en el Excel real es la columna `OPORTUNIDAD` (Oportuno/No ejecutado/Posterior), pero es un juicio manual del formador/analista, no un cálculo derivado de timestamps — es decir, hoy en la práctica **tampoco se calcula automáticamente en el Excel real**, se diligencia a mano. |

**Indicador que no podrá calcularse sin cambios de arquitectura:** *Puntualidad*, mientras no exista la relación Programación ↔ Ejecución. Este es el hallazgo más importante de esta sección y debe decidirse antes de construir los indicadores.

---

## 8. Consistencia del modelo — campos del mockup sin respaldo en los requerimientos

**Con respaldo claro en PDF y/o Excel** (mantener, ajustando valores/tipo de campo según lo detectado): ID Actividad, Fecha programada, Tipo de actividad, Formador responsable, Campaña, Canal, Duración, Estado, Observaciones generales, Participantes esperados (parcial, dato disperso en el Excel).

**Agregados por diseño, sin respaldo documental — requieren validación explícita del cliente antes de construirse:**
- Hora inicio / Hora fin programada (el Excel solo tiene minutos totales).
- Modalidad (tiene catálogo real en Excel, pero el PDF no lo pide para este libro).
- Grupo de formación (no está en la hoja real de Programación).
- Toda la sección "2. Detalle de la actividad" (Objetivo, Contenido, Metodología, Recursos) — el Excel real solo tiene un campo de texto libre combinado.
- Toda la sección "3. Participantes programados" excepto el número esperado (Grupo objetivo, Criterio de selección, Lista de participantes).
- Toda la sección "4. Lugar/Plataforma" (Lugar, Enlace).
- Registrado por / Confirmado por (hoy con datos ficticios/hardcodeados).
- Toda la sección "6. Confirmación y seguimiento" — funcionalmente pertenece al Libro 6 ya construido.

**Podrían eliminarse o fusionarse:**
- La sección 6 completa, si se decide que el cierre de la actividad vive únicamente en `actividad.ejecutada` y Programación solo referencia esa ejecución.
- El campo "Metodología" de la sección 2, si se confirma que es una duplicación conceptual del campo "Modalidad" de la sección 1 (mismo catálogo fuente en el Excel: PRESENCIAL/VIRTUAL/MIXTA).

**Hace falta (según el PDF, no está bien resuelto hoy):**
- Un **catálogo real** de "Tipo de actividad" (`training.activity.type` o similar) con los 4 valores oficiales del Excel, en vez de un `Selection` inventado y además distinto entre Programación y Actividades Ejecutadas.
- La **relación** entre Programación y Actividades Ejecutadas.
- El **cálculo real** de la duración.

---

## 9. Dependencias — qué debe existir antes de desarrollar este libro

| Dependencia | Estado actual | Obligatoria para Libro 5 |
|---|---|---|
| `training.campaign` (Campañas) | Ya existe y ya se usa en `programacion.actividad` | Sí — ya satisfecha |
| `training.trainer` (Formadores) | Ya existe y ya se usa | Sí — ya satisfecha |
| `training.group` (Grupos) | Ya existe; su uso en este libro es cuestionable (ver sección 2) | A confirmar con cliente |
| `training.channel` (Canales) | Ya existe, pero **no se usa** en `programacion.actividad` (se usa `Selection` en su lugar) | Sí, si se corrige la inconsistencia señalada |
| Catálogo de "Tipo de actividad" | **No existe como modelo** — hoy es `Selection` hardcodeada y no coincide con los valores reales del Excel | Sí, recomendado crear antes de construir el libro, siguiendo el mismo patrón que los demás catálogos `training.*` |
| `res.users` para "registrado por"/"confirmado por" | Ya existe en Odoo (estándar); el módulo ya usa `create_uid` en `registro_fi` como patrón | Sí, si se mantienen estos campos |
| Relación con `actividad.ejecutada` | No existe | Depende de la decisión sobre el hallazgo #2/#3 del resumen ejecutivo — es un prerrequisito de diseño, no de datos |

---

## 10. Orden recomendado de implementación

**Fase 0 — Decisiones con el cliente (antes de tocar el modelo actual)**
Resolver, con evidencia de este documento, las tres preguntas abiertas: (a) ¿los 4 estados del Libro 5 son los del PDF o los de aprobación que hoy tiene el mockup?, (b) ¿la sección "Confirmación y seguimiento" se elimina de este libro y vive solo en Actividades Ejecutadas?, (c) ¿qué secciones sin respaldo documental (Detalle, Participantes, Lugar) se conservan tal cual, se recortan o se confirman como alcance real?

**Fase 1 — Modelado de datos**
Corregir tipos de campo mal escogidos (canal a `Many2one`, duración a numérico calculado, usuario/fecha de registro a `related`/`compute`), y crear el catálogo de "Tipo de actividad" con los valores reales del Excel.

**Fase 2 — Relaciones**
Vincular `canal_id` a `training.channel`; si Fase 0 lo confirma, crear la relación entre `programacion.actividad` y `actividad.ejecutada`.

**Fase 3 — Validaciones**
Trasladar los patrones ya probados en el módulo (regex de horas, coherencia de fechas, longitud de textos —esta última ya está bien— ) a los campos de este libro que hoy no tienen ninguna validación (horas, estado).

**Fase 4 — Automatizaciones**
Cálculo real de duración, derivación de usuario/fecha de registro, y (si aplica) derivación del estado "Ejecutada" desde la relación con el Libro 6.

**Fase 5 — Indicadores**
Construir primero los tres indicadores totalmente calculables (Total, Horas programadas, % Programado). Dejar "Actividades promedio por día" y "Puntualidad" para después de que el cliente defina la regla de "número de días" y se resuelva la relación con Actividades Ejecutadas, respectivamente.

**Fase 6 — Reportes**
Vistas de lista/pivote/gráfico equivalentes a las hojas "TD" que ya usa el Excel actual (`7.1. PROGRAMACIÓN TD`), una vez los datos y los estados sean confiables.

---

## Addendum — Revisión de la implementación actualizada (`programacion_actividad.py` v2 + vista v2)

Se entregó una nueva versión del modelo y la vista con cambios reales de lógica (constraint de unicidad, cálculo de duración, validaciones de horario, automatización de estado, validaciones de sección 6). Esta sección audita, punto por punto, cuáles de los 7 hallazgos críticos del cuerpo del documento quedaron resueltos y cuáles siguen abiertos, más los hallazgos nuevos que introduce esta versión.

### Estado de los 7 hallazgos críticos originales

| # | Hallazgo original | Estado ahora | Evidencia |
|---|---|---|---|
| 1 | `estado_programacion` no usa los 4 estados del PDF (Programada/Ejecutada/Reprogramada/Cancelada), sino un flujo de aprobación inventado | **Sigue abierto** | La lista de valores no cambió: `programada/revision/aprobada/cancelada`. Sigue sin existir un valor "Ejecutada" en este campo. |
| 2 | La sección 6 duplica el propósito del Libro 6 (`actividad.ejecutada`) | **Sigue abierto, y ahora con más lógica invertida en sostenerlo** | Se añadieron 4 `@api.constrains` nuevas (`_check_fecha_confirmacion`, `_check_confirmado_por`, `_check_fecha_ejecucion`, `_check_estado_final`) dedicadas por completo a esta sección. Es decir, en vez de resolverse la superposición con el Libro 6, se invirtió más esfuerzo en consolidarla dentro de Programación. |
| 3 | No hay relación (`Many2one`) entre `programacion.actividad` y `actividad.ejecutada` | **Sigue abierto** | No se agregó ningún campo de relación entre ambos modelos. **Puntualidad** y el "% Programado" tal como los define el PDF siguen sin poder calcularse. |
| 4 | `tipo_actividad` y `canal` usan catálogos inventados, no los valores reales del Excel | **Sigue abierto** | `tipo_actividad` sigue siendo `induccion/formacion/refuerzo/coaching/retroalimentacion/otro`. `canal` sigue siendo `voz/chat/correo`. Ninguno coincide con el catálogo oficial (`ADMINISTRATIVA/FORMACIÓN INICIAL/INTERVENCIÓN FORMATIVA ESPECÍFICA/PLAN DE INTERVENCIÓN FORMATIVA` y `IN Y OUT/INBOUND/OUTBOUND`). |
| 5 | `duracion` no tenía `compute`; además, como texto, no es sumable | **Resuelto a medias** | Ahora **sí** existe `_compute_duracion` + `_calcular_duracion`, con validación de formato de hora y hora fin > hora inicio (`_check_horas_programadas`) — bien resuelto y coherente con el patrón de `control_asistencia`. Pero el campo sigue siendo `Char` (`"02:30"`), por lo que **"Horas programadas" (suma de duración) sigue sin ser calculable con una simple suma** — seguiría necesitando un campo numérico paralelo (minutos u horas decimales). |
| 6 | `canal` no sigue el patrón `Many2one → training.channel` que usa el resto del módulo | **Sigue abierto** | Continúa siendo `Selection` de texto libre. |
| 7 | Secciones "Participantes" y "Lugar/Plataforma" sin respaldo documental | **Sigue abierto (y ahora obligatorio)** | `participantes_esperados`, `grupo_objetivo` y `lugar` pasaron a `required=True`. Esto no resuelve el hallazgo — lo profundiza: se está exigiendo como obligatorio un dato que el histórico del Excel solo diligenció el 39% de las veces, sin que conste una confirmación del cliente de que ahora sí se comprometerá a hacerlo siempre. |

**Resumen:** de los 7 hallazgos críticos, **solo el 5 tuvo avance real (parcial)**. Los otros 6 siguen exactamente igual que en la primera revisión.

### Hallazgos nuevos introducidos por esta versión

**a) La automatización "estado → Programada cuando está completa" quedó parcialmente inutilizada por los `required=True` añadidos.**
Al marcar como `required=True` casi todos los campos de `CAMPOS_PROGRAMACION_COMPLETA` (incluido el propio `estado_programacion`, que además perdió su `default="programada"`), un registro **nunca puede quedar guardado en estado "incompleto"** — Odoo bloquea el guardado si falta cualquiera de esos campos, con o sin la lógica de `_onchange_programacion_completa`/`create`/`write`. Efectos concretos:
- El bloque de `write()` que reevalúa `self.filtered(lambda r: not r.estado_programacion)` **es código muerto**: como `estado_programacion` es obligatorio desde la creación, jamás puede existir un registro guardado con ese campo vacío, así que el `filtered` siempre devuelve un conjunto vacío.
- El `onchange` (`_onchange_programacion_completa`) sigue siendo funcional durante el diligenciamiento interactivo del formulario (si el usuario no ha tocado el widget de estado, se le preselecciona "Programada" al completar el último campo obligatorio), pero es redundante en la práctica porque el propio `required=True` ya obliga a completar todo antes de poder guardar — el concepto de "actividad completa vs. incompleta" que le da sentido a esta automatización ya no existe como tal en el modelo de datos.
- La rama `if not record.estado_programacion:` dentro de `_check_fecha_confirmacion` también es inalcanzable por la misma razón.
Esto no es un error que rompa el guardado, pero sí es lógica que quedó **contradiciendo su propio propósito de diseño**: se construyó un mecanismo para distinguir programaciones completas de incompletas, y luego se volvieron obligatorios todos los campos que ese mecanismo necesitaba para tener sentido.

**b) `registrado_por` sigue con usuarios ficticios (`usuario1/usuario2/usuario3`) y ahora es obligatorio.**
Antes era un placeholder inofensivo porque no era obligatorio de facto en la lógica; ahora, al ser `required=True`, **todo usuario real del sistema queda forzado a elegir entre 3 nombres falsos** para poder guardar cualquier actividad. Esto pasó de ser una inconsistencia menor a un bloqueo funcional real si se usa en producción tal cual.

**c) `id_actividad` tiene ahora restricción de unicidad, pero sin la normalización que sí tienen sus pares.**
Se agregó `_sql_constraints unique(id_actividad)` — correcto y alineado con `acompanamiento.id_monitoreo` y `control_asistencia.id_sesion`. Pero, a diferencia de esos dos modelos, `programacion.actividad` **no sobreescribe `create`/`write` para hacer `.strip().upper()`** sobre `id_actividad`. Con esto, `"ACT-001"`, `"act-001"` y `"ACT-001 "` se consideran valores distintos y la restricción de unicidad no los detecta como duplicados — el mismo problema que esa restricción busca evitar puede colarse por diferencias de mayúsculas/espacios.

**d) Falta simetría entre la sección 5 y la sección 6 en materia de limpieza automática.**
`_onchange_estado_final` limpia `fecha_ejecucion` automáticamente cuando `estado_final` deja de ser "ejecutada" — buen patrón. Pero no existe un `onchange` equivalente que limpie `fecha_confirmacion`/`confirmado_por` cuando `estado_programacion` cambia a "cancelada", pese a que `_check_fecha_confirmacion` bloquea justamente esa combinación. Resultado: un usuario que ya diligenció confirmación y luego cancela la actividad se topará con un error de validación sin que el formulario le ayude a corregirlo automáticamente, a diferencia de lo que sí ocurre en el caso simétrico de estado final/fecha de ejecución.

### Cobertura frente a lo que pide el PDF (campos + fórmulas del Libro 5)

| Requerido por el PDF | ¿Cubierto hoy? |
|---|---|
| ID actividad, Fecha programada, Tipo actividad, Formador, Campaña, Canal, Duración, Estado | Los 8 campos existen, pero **Tipo actividad**, **Canal** y **Estado** tienen valores que no corresponden a lo pedido/real (ver hallazgos 1, 4, 6). |
| Total actividades programadas | Calculable (conteo simple). |
| Horas programadas | **No calculable todavía** — `duracion` sigue siendo texto, no numérico. |
| Actividades promedio por día | Pendiente de que el cliente defina "número de días" (no es un problema de código). |
| % Programado | **No calculable de forma fiel a la fórmula** mientras `estado_programacion` no incluya "Ejecutada" y no exista relación con `actividad.ejecutada`. |
| Puntualidad | **No calculable** — sigue sin existir la relación Programación↔Ejecución. |

### Veredicto

No, **la lógica de este libro todavía no está completa** frente a lo que pide el PDF. Esta iteración mejoró notablemente la calidad interna del código (validaciones de horario, unicidad de ID, cálculo real de duración, validaciones de la sección de confirmación/seguimiento), pero **no tocó ninguno de los 6 hallazgos estructurales** que impiden que 2 de las 5 fórmulas del libro (Horas programadas de forma sumable, y sobre todo Puntualidad) se puedan calcular, y **introdujo un bloqueo funcional nuevo** (`registrado_por` obligatorio con usuarios falsos) que antes no existía en la práctica.

### Precisión posterior — evaluación acotada solo a lo que pide el PDF para el Libro 5

El punto anterior evaluó `programacion.actividad` en el contexto de todo el módulo (comparándolo contra `actividad.ejecutada` y contra los patrones de los libros hermanos). Acotando el análisis **estrictamente a los campos y las 4 fórmulas que el PDF pide para este libro**, sin considerar el resto del módulo, la conclusión se mantiene pero por una razón más simple y precisa:

- Los 7 campos + Estado que pide el PDF **sí existen todos** en el modelo.
- De las 5 fórmulas, solo **"Total actividades programadas"** es calculable de forma confiable hoy.
- **"Horas programadas"** falla por una razón interna al propio libro: `duracion` es texto (`"02:30"`), no numérico, así que no se puede sumar — no depende de ningún otro libro, es un ajuste que se resuelve dentro de `programacion.actividad`.
- **"% Programado"** es *técnicamente* consultable (`estado_programacion == "programada"` sobre el total), pero el resultado no sería fiel a la fórmula: como ningún mecanismo mueve un registro fuera de `"programada"` cuando la actividad ya se ejecutó, reprogramó o ejecutó tarde, ese contador crecería indefinidamente y el porcentaje no reflejaría la intención de la fórmula del PDF.
- **"Puntualidad"** no es calculable por un motivo que tampoco depende de otro libro: el modelo nunca captura una hora de inicio *real* — `hora_inicio`/`hora_fin` son solo las programadas, y `fecha_ejecucion` es una fecha sin hora. No hay con qué comparar "inició a tiempo".
- El campo "Estado" del PDF pide un único campo con 4 valores (Programada/Ejecutada/Reprogramada/Cancelada). El modelo lo implementa como **dos campos separados** (`estado_programacion`: programada/revisión/aprobada/cancelada; `estado_final`: ejecutada/reprogramada/cancelada/no_ejecutada — este último no obligatorio), y ninguno de los dos por sí solo contiene los 4 valores que pide el PDF.

Es decir: incluso mirando el libro de forma aislada, sin comparar con `actividad.ejecutada` ni con los demás libros del módulo, **2 de las 4 fórmulas (Horas programadas, Puntualidad) y el campo Estado no quedan resueltos según lo que el propio PDF pide para este libro.**

---

## Preguntas abiertas que requieren respuesta directa del cliente (no deben resolverse por suposición)

1. ¿Los estados del Libro 5 son los 4 del PDF (Programada/Ejecutada/Reprogramada/Cancelada) o el flujo de aprobación que ya tiene el mockup (Programada/En revisión/Aprobada/Cancelada)? Son incompatibles entre sí.
2. ¿La ejecución de una actividad (fecha real, estado final) se registra en este libro, en el Libro 6, o en ambos con relación entre sí?
3. ¿"Objetivo" y "Contenido" deben capturarse como dos campos separados, o se mantiene el campo de texto único que usan hoy en el Excel?
4. ¿"Modalidad" (sección 1) y "Metodología" (sección 2) son dos conceptos distintos en la operación real, o es una duplicación que debe unificarse?
5. ¿Se compromete el negocio a diligenciar siempre "Participantes esperados", dado que hoy solo lo hacen el 39% de las veces?
6. ¿Debe existir "Lugar/Plataforma" y "Enlace" como campos formales, o es información que hoy vive en otro lugar (agenda, correo, etc.) y no necesita capturarse aquí?
7. ¿Cómo se define operativamente "número de días" para el indicador "Actividades promedio por día"?
