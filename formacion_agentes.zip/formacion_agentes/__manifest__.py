{
    'name': 'Formación Agentes',
    'summary': 'Gestiona la formación y certificación de agentes',
    'version': '1.0.0',
    'author': 'Custom',
    'website': 'https://example.com',
    'category': 'Human Resources',
    'license': 'LGPL-3',

    'depends': [
        'base',
        'web',
    ],

    'data': [
        'security/ir.model.access.csv',

        # Vistas
        'views/registro_fi_views.xml',
        'views/acompanamiento_views.xml',
        'views/plan_intervencion_views.xml',
        'views/control_asistencia_views.xml',
        'views/programacion_actividad_views.xml',
        'views/actividad_ejecutada_views.xml',

        # Menú
        'views/menu.xml',
    ],

    'assets': {
        'web.assets_backend': [

            # CSS
            'formacion_agentes/static/src/css/formacion.css',

            # Widgets Registro FI
            'formacion_agentes/static/src/js/concepto_final_buttons.js',
            'formacion_agentes/static/src/xml/concepto_final_buttons.xml',

            # Widgets Calidad (Acompañamiento)
            'formacion_agentes/static/src/js/quality_widgets.js',
            'formacion_agentes/static/src/xml/quality_widgets.xml',
        ],
    },

    'installable': True,
    'application': True,
}