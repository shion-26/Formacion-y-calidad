{
    'name': 'Formación Agentes',
    'summary': 'Gestiona la formación y certificación de agentes',
    'version': '1.0.0',
    'author': 'Custom',
    'website': 'https://example.com',
    'category': 'Human Resources',
    'license': 'LGPL-3',

    'depends': [
        'base',
        'web',
    ],

    'data': [
        # Seguridad
        'security/ir.model.access.csv',

        # Vistas
        'views/registro_fi_views.xml',
        'views/acompanamiento_views.xml',
        'views/plan_intervencion_views.xml',
        'views/control_asistencia_views.xml',
        'views/programacion_actividad_views.xml',
        'views/actividad_ejecutada_views.xml',

        # Menús
        'views/menu.xml',
    ],

    'assets': {
        'web.assets_backend': [

            # CSS
            'formacion_agentes/static/src/css/formacion.css',

            # Registro FI
            'formacion_agentes/static/src/js/concepto_final_buttons.js',
            'formacion_agentes/static/src/xml/concepto_final_buttons.xml',

            # Acompañamiento
            'formacion_agentes/static/src/js/quality_widgets.js',
            'formacion_agentes/static/src/xml/quality_widgets.xml',

            # Planes de Intervención
            'formacion_agentes/static/src/js/estado_plan_buttons.js',
            'formacion_agentes/static/src/xml/estado_plan_buttons.xml',

            'formacion_agentes/static/src/js/file_dropzone_widget.js',
            'formacion_agentes/static/src/xml/file_dropzone_widget.xml',
        ],
    },

    'installable': True,
    'application': True,
}