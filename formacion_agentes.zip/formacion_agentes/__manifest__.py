{
    'name': 'Formación Agentes',
    'summary': 'Gestiona la formación y certificación de agentes',
    'version': '1.0.0',
    'author': 'Custom',
    'website': 'https://example.com',
    'category': 'Human Resources',
    'license': 'LGPL-3',

    'depends': [
        'base',
        'web',
        'hr',
    ],

    'data': [
        # Seguridad
        'security/ir.model.access.csv',

        # Vistas
        'views/registro_fi_views.xml',
        'views/acompanamiento_views.xml',
        'views/plan_intervencion_views.xml',
        'views/control_asistencia_views.xml',
        'views/programacion_actividad_views.xml',
        'views/actividad_ejecutada_views.xml',
        'views/training_campaign_views.xml',
        'views/training_group_views.xml',
        'views/training_trainer_views.xml',
        'views/training_entry_type_views.xml',

        # Menús
        'views/menu.xml',
    ],

    'assets': {
        'web.assets_backend': [

            # CSS
            'formacion_agentes/static/src/css/formacion.css',

            # Registro FI
            'formacion_agentes/static/src/js/concepto_final_buttons.js',
            'formacion_agentes/static/src/xml/concepto_final_buttons.xml',

            # Acompañamiento
            'formacion_agentes/static/src/js/quality_widgets.js',
            'formacion_agentes/static/src/xml/quality_widgets.xml',

            # Planes de Intervención
            'formacion_agentes/static/src/js/estado_plan_buttons.js',
            'formacion_agentes/static/src/xml/estado_plan_buttons.xml',

            'formacion_agentes/static/src/js/file_dropzone_widget.js',
            'formacion_agentes/static/src/xml/file_dropzone_widget.xml',

            # Control de Asistencia
            'formacion_agentes/static/src/js/estado_asistencia_buttons.js',
            'formacion_agentes/static/src/xml/estado_asistencia_buttons.xml',

            # Programación de Actividades
            'formacion_agentes/static/src/js/estado_programacion_buttons.js',
            'formacion_agentes/static/src/xml/estado_programacion_buttons.xml',

            'formacion_agentes/static/src/js/estado_final_actividad_buttons.js',
            'formacion_agentes/static/src/xml/estado_final_actividad_buttons.xml',

            # Actividades Ejecutadas
            'formacion_agentes/static/src/js/actividad_ejecutada_buttons.js',
            'formacion_agentes/static/src/xml/actividad_ejecutada_buttons.xml',

            'formacion_agentes/static/src/js/estado_ejecucion_buttons.js',
            'formacion_agentes/static/src/xml/estado_ejecucion_buttons.xml',
        ],
    },

    'installable': True,
    'application': True,
}